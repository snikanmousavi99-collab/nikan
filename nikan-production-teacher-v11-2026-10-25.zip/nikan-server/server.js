/**
 * سامانه نیکان — سرور Node.js (جایگزین Cloudflare Worker)
 * مسیرهای API و شکل پاسخ‌ها عمداً با نسخه قبلی یکی است تا اپ اندروید خراب نشود.
 */
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');
const { db, ensureSchema, sqlite } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const MOTHER_KEY = process.env.MOTHER_KEY || '';

app.use(cors({ origin: true, credentials: true }));
// افزایش سقف بدنه برای بکاپ کامل با عکس‌های base64 دانش‌آموز/پرسنل
app.use('/api/parents', express.json({ limit: '5mb' }));
app.use(['/api/login','/api/mother/login','/api/register','/api/activate'], express.json({limit:'16kb'}), express.urlencoded({extended:false,limit:'16kb'}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
require('./lib/security').installRequestSecurity(app,{sqlite,getAuth,json});

/** gzip برای پاسخ‌های بزرگ (HTML ~700KB → ~150KB) */
function wantsGzip(req) {
  const ae = String(req.headers['accept-encoding'] || '');
  return ae.includes('gzip');
}
function sendGzipBuffer(req, res, buf, contentType, cacheControl) {
  res.setHeader('Content-Type', contentType);
  if (cacheControl) res.setHeader('Cache-Control', cacheControl);
  if (wantsGzip(req) && buf.length > 1024) {
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    return zlib.gzip(buf, (error, compressed) => {
      if(error){res.removeHeader('Content-Encoding');return res.end(buf);}
      res.end(compressed);
    });
  }
  res.end(buf);
}
function json(res, data, status = 200) {
  res.setHeader('Cache-Control','no-store');
  const body = Buffer.from(JSON.stringify(data), 'utf8');
  res.status(status);
  // اگر req در scope نیست از res.req استفاده کن
  const req = res.req;
  if (req && wantsGzip(req) && body.length > 2048) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    return zlib.gzip(body, (error, compressed) => {
      if(error){res.removeHeader('Content-Encoding');return res.end(body);}
      res.end(compressed);
    });
  }
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(body);
}


function motherKeyOk(req) {
  if (!MOTHER_KEY) return false;
  const h = req.headers['x-mother-key'] || req.headers['x-api-key'] || '';
  return safeEqual(h, MOTHER_KEY);
}

function authHeader(req, name) {
  const value = String(req.headers[name] || '');
  return req.headers['x-auth-encoding'] === 'uri-component' ? decodeURIComponent(value) : value;
}

function getAuth(body, req) {
  const a = (body && body.auth) || {};
  return {
    user: String(a.user || authHeader(req, 'x-auth-user') || '').trim(),
    pass: String(a.pass || authHeader(req, 'x-auth-pass') || ''),
    role: String(a.role || req.headers['x-auth-role'] || '').trim().toLowerCase(),
    schoolId: String(a.schoolId || '').trim()
  };
}

function normalizeRole(role) {
  const value = String(role || '').toLowerCase();
  if (['manager', 'مدیر'].includes(value)) return 'manager';
  if (['deputy', 'assistant', 'معاون'].includes(value)) return 'deputy';
  if (['teacher', 'معلم', 'دبیر'].includes(value)) return 'teacher';
  return value;
}

function validMotherAccount(saved) {
  return saved && typeof saved.user === 'string' && saved.user && typeof saved.salt === 'string' &&
    /^[a-f0-9]{32}$/i.test(saved.salt) && typeof saved.hash === 'string' && /^[a-f0-9]{128}$/i.test(saved.hash);
}

// Private deployment input, never an HTTP recovery mechanism. Existing accounts always win.
function bootstrapMotherAccount() {
  try {
    if (sqlite.prepare('SELECT school_id FROM app_data WHERE school_id=?').get('__mother_auth__') ||
        (process.env.MOTHER_PASSWORD || '').length >= 6) return '';
    const filename = process.env.MOTHER_BOOTSTRAP_FILE === undefined
      ? path.join(__dirname, 'mother-bootstrap.json') : process.env.MOTHER_BOOTSTRAP_FILE;
    if (!filename) return '';
    let content;
    try { content = fs.readFileSync(filename); }
    catch (error) { if (error.code === 'ENOENT') return ''; throw error; }
    if (content.length > 16384) throw new Error('invalid_bootstrap');
    const saved = JSON.parse(content.toString('utf8'));
    if (!validMotherAccount(saved) || saved.version !== 1 ||
        Object.keys(saved).some(key => !['version', 'user', 'salt', 'hash'].includes(key))) throw new Error('invalid_bootstrap');
    sqlite.prepare('INSERT INTO app_data(school_id,data,updated_at) VALUES(?,?,?) ON CONFLICT(school_id) DO NOTHING')
      .run('__mother_auth__', JSON.stringify({ user: saved.user, salt: saved.salt, hash: saved.hash }), Date.now());
    return '';
  } catch {
    console.error('Mother account bootstrap unavailable; verify the private deployment file or use mother:setup.');
    return 'mother_account_unavailable';
  }
}
const motherBootstrapError = bootstrapMotherAccount();

function motherAccountState() {
  const row = db.prepare('SELECT data FROM app_data WHERE school_id = ?').bind('__mother_auth__').first();
  if (row) {
    try {
      const saved = JSON.parse(row.data);
      if (!validMotherAccount(saved)) throw new Error('invalid_account');
      return { configured: true, saved };
    } catch { return { configured: false, error: 'mother_account_unavailable' }; }
  }
  const password = process.env.MOTHER_PASSWORD || '';
  return { configured: password.length >= 6, user: process.env.MOTHER_USER || 'admin', password,
    error: motherBootstrapError || 'mother_not_configured' };
}
function motherCredentialsOk(auth, account) {
  if (typeof auth.user !== 'string' || typeof auth.pass !== 'string' || !auth.user || !auth.pass || normalizeRole(auth.role) !== 'mother') return false;
  account = account || motherAccountState();
  if (!account.configured) return false;
  if (account.saved) {
    if(auth.user!==account.saved.user)return false;
    const actual = crypto.scryptSync(auth.pass, account.saved.salt, 64);
    return auth.user === account.saved.user && crypto.timingSafeEqual(actual, Buffer.from(account.saved.hash, 'hex'));
  }
  return auth.user === account.user && safeEqual(auth.pass, account.password);
}

function safeEqual(a, b) {
  const left = crypto.createHash('sha256').update(String(a)).digest();
  const right = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(left, right);
}

function schoolUnavailable(school) {
  if (school.active === false) return 'school_inactive';
  // The license includes the final calendar day in Tehran.
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tehran' }).format(new Date());
  if (school.expireDate && String(school.expireDate).slice(0, 10) < today) return 'license_expired';
  return '';
}

function authenticateWrite(req, schoolId, body) {
  if (req.viewer) return req.viewer;
  if (motherKeyOk(req)) return { ok: true, role: 'mother' };
  const auth = getAuth(body, req);
  if (motherCredentialsOk(auth)) return { ok: true, role: 'mother' };
  if (!schoolId) return { ok: false, error: 'auth_required' };
  const school = loadSchoolRow(schoolId);
  if (!school) return { ok: false, error: 'school_not_found' };
  const unavailable = schoolUnavailable(school);
  if (unavailable) return { ok: false, error: unavailable };
  const data = loadAppData(schoolId);
  req.authAppData = data;
  const user = String(data.managerUser || school.managerUsername || school.managerUser || '').trim();
  const pass = String(data.managerPass || school.managerPassword || school.managerPass || '');
  if (auth.user && auth.pass && auth.user === user && safeEqual(auth.pass, pass)) {
    return { ok: true, role: 'manager', user, schoolId };
  }
  const staff = (data.staff || []).find(s => s && s.active !== false &&
    String(s.username || s.user || '').trim() === auth.user &&
    auth.pass && safeEqual(auth.pass, String(s.pass || s.password || '')));
  if (staff && ['teacher', 'deputy'].includes(normalizeRole(staff.role || 'teacher'))) {
    return { ok: true, role: normalizeRole(staff.role || 'teacher'), user: auth.user,
      staffId: String(staff.id), schoolId, shift: normShiftVal(staff.shift) };
  }
  return { ok: false, error: 'auth_required' };
}

function viewerQuery(req) {
  const viewer = req.viewer;
  if (viewer && ['teacher', 'deputy'].includes(viewer.role)) {
    return { scope: 'mine', role: viewer.role, staffId: viewer.staffId, user: viewer.user };
  }
  return {};
}

function authenticatedSchool(school, role) {
  const safe = publicSchool(school);
  if (['mother', 'manager'].includes(role)) {
    for (const key of ['managerName', 'managerPhone', 'city', 'smsMode', 'smsApiUrl', 'smsApiUser', 'smsApiKey', 'smsSender']) {
      if (school[key] !== undefined) safe[key] = school[key];
    }
  }
  return safe;
}

function publicSchool(school) {
  const out = {};
  for (const key of ['id', 'code', 'name', 'active', 'expireDate', 'shifts', 'modules', 'maxUsers', 'plan', 'startDate']) {
    if (school[key] !== undefined) out[key] = school[key];
  }
  return out;
}

// Identity and privileges are always derived from stored credentials, never request flags.
function authorizeApi(req, res, next) {
  try {
    const p = req.path;
    if (req.body && (Array.isArray(req.body) || typeof req.body !== 'object')) return json(res, { ok: false, error: 'invalid_body' }, 400);
    for (const key of ['classes', 'students', 'staff', 'assignments', 'attendance', 'submissions', 'messages', 'exams', 'teacherNotes', 'sampleQuestions', 'classMessages', 'disciplinePhotos', 'deletedAttendanceIds', 'deletedAttendanceKeys', 'deletedSubmissionIds', 'deletedStudentIds', 'deletedClassMessageIds', 'deletedClassIds', 'deletedStaffIds', 'deletedAssignmentIds', 'deletedExamIds', 'deletedMessageIds', 'deletedTeacherNoteIds', 'deletedSampleQuestionIds', 'deletedDisciplinePhotoIds']) {
      if (req.body && req.body[key] !== undefined && (!Array.isArray(req.body[key]) || req.body[key].some(x => x == null))) return json(res, { ok: false, error: 'invalid_' + key }, 400);
    }
    // IDs are interpolated into legacy inline actions; constrain them at the write boundary.
    const validateIds = (value, depth = 0) => {
      if (depth > 50) throw new Error('invalid_nesting');
      if (!value || typeof value !== 'object') return;
      for (const [key, item] of Object.entries(value)) {
        if (/^(id|classId|studentId|teacherId|teacherId2|teacherId3|staffId|assignId|submissionId)$/.test(key) && item != null && item !== '' &&
            (!/^[a-zA-Z0-9_.:-]+$/.test(String(item)) || ['__proto__', 'constructor', 'prototype'].includes(String(item)))) throw new Error('invalid_id');
        if (item && typeof item === 'object') validateIds(item, depth + 1);
      }
    };
    validateIds(req.body);
    const publicPath = ['/health', '/', '/login', '/mother/login', '/register', '/activate'].includes(p) ||
      (req.method === 'GET' && (p === '/branding' || p === '/parent-branding' || p.startsWith('/schools/by-code/')));
    if (publicPath) return next();
    const match = p.match(/^\/schools\/([^/]+)/);
    const schoolId = match ? decodeURIComponent(match[1]) : String((req.body || {}).schoolId || (req.body || {}).id || '');
    const viewer = authenticateWrite(req, schoolId, req.body || {});
    if (!viewer.ok) return json(res, { ok: false, error: viewer.error }, 401);
    req.viewer = viewer;
    if (viewer.role !== 'teacher') {
      delete req.body.teacherNotes;
      delete req.body.deletedTeacherNoteIds;
    }
    delete req.body._teacherNoteDeletionOwners;
    const manager = ['mother', 'manager'].includes(viewer.role);
    if ((p === '/schools' && req.method === 'GET') || p === '/branding' || p === '/parent-branding' || p === '/mother/account' ||
        (match && p === match[0] && req.method === 'DELETE')) {
      if (viewer.role !== 'mother') return json(res, { ok: false, error: 'forbidden' }, 403);
    }
    if (/\/(reset-year|submissions\/clear)$/.test(p) && !manager) {
      return json(res, { ok: false, error: 'forbidden' }, 403);
    }
    if (p === '/sms/send' && viewer.role === 'teacher') return json(res, { ok: false, error: 'forbidden' }, 403);
    if (match && req.method !== 'GET' && !manager && p.includes('/appData')) {
      const full = loadAppData(schoolId);
      const scoped = scopeAppDataForViewer(full, viewerQuery(req));
      const body = req.body || {};
      if (body.resetYear || body.clearPerformance || body._fullRestore || body._bypassPerfFilter) {
        return json(res, { ok: false, error: 'forbidden' }, 403);
      }
      if (p.endsWith('/structure') && viewer.role !== 'deputy') return json(res, { ok: false, error: 'forbidden' }, 403);
      const classIds = new Set((scoped.classes || []).map(x => String(x.id)));
      const studentIds = new Set((scoped.students || []).map(x => String(x.id)));
      const assignmentIds = new Set((scoped.assignments || []).map(x => String(x.id)));
      const owns = x => !!x &&
        (!x.classId || classIds.has(String(x.classId))) &&
        (!x.studentId || studentIds.has(String(x.studentId))) &&
        (!x.assignId || assignmentIds.has(String(x.assignId))) &&
        !!(x.classId || x.studentId || x.assignId || String(x.teacherId || '') === viewer.staffId);
      const allowed = ['attendance', 'submissions', 'exams', 'teacherNotes', 'sampleQuestions', 'messages', 'classMessages', 'staffSelfUpdate',
        'updatedAtMs', '_teacherPartial', '_softOnly', '_partialDelta', 'auth', 'schoolId',
        'deletedExamIds', 'deletedMessageIds', 'deletedTeacherNoteIds', 'deletedSampleQuestionIds'];
      if (viewer.role === 'deputy') allowed.push('students', 'deletedStudentIds', 'deletedAttendanceIds',
        'deletedAttendanceKeys', 'deletedSubmissionIds', '_reviewOne', 'disciplineTypes', 'rules', 'smsTemplates',
        'classMsgTemplates', 'deletedClassMessageIds', 'disciplinePhotos', 'deletedDisciplinePhotoIds', 'absentSmsSent');
      const chargedAbsentDays = new Set((full.attendance || []).filter(a => a.type === 'absent' && Number(a.scoreDeduct) > 0).map(a => String(a.studentId) + '|' + String(a.date)));
      const clean = {};
      for (const key of allowed) if (body[key] !== undefined) clean[key] = body[key];
      for (const field of ['attendance', 'submissions', 'exams', 'teacherNotes', 'sampleQuestions']) {
        if (clean[field] !== undefined) {
          if (!Array.isArray(clean[field])) return json(res, { ok: false, error: 'invalid_' + field }, 400);
          clean[field] = clean[field].filter(x => (field !== 'teacherNotes' || viewer.role === 'teacher') && owns(x) &&
            !(field === 'attendance' && x.submissionId && (full.deletedSubmissionIds || []).includes(String(x.submissionId)))).map(x => {
            const old = (full[field] || []).find(r => String(r.id) === String(x.id)) ||
              (field === 'attendance' && x.submissionId && (full.attendance || []).find(r => sameAttendanceEvent(r, x)));
            if (old && (!owns(old) || (field === 'teacherNotes' && String(old.teacherId || '') !== viewer.staffId))) throw new Error('record_forbidden');
            if (viewer.role !== 'teacher') return x;
            if (old && String(old.teacherId || '') !== viewer.staffId) return old;
            const out = Object.assign({}, x, { teacherId: viewer.staffId });
            if (field === 'attendance' && old) out.id = old.id;
            if (field === 'exams') {
              const max = Number(out.maxScore == null ? 20 : out.maxScore);
              if (!Number.isFinite(max) || max <= 0 || (out.scores !== undefined &&
                  (!out.scores || Array.isArray(out.scores) || typeof out.scores !== 'object'))) throw new Error('invalid_exam');
              for (const [sid, score] of Object.entries(out.scores || {})) {
                const student = (scoped.students || []).find(st => String(st.id) === sid);
                if (!student || String(student.classId) !== String(out.classId) || typeof score !== 'number' ||
                    !Number.isFinite(score) || score < 0 || score > max) throw new Error('invalid_score');
              }
            }
            if (Array.isArray(out.rows)) out.rows = out.rows.filter(row => studentIds.has(String(row.studentId)));
            for (const key of ['excused', 'justified', 'scoreLocked', 'scoreDeduct', 'reviewedAt', 'reviewedBy', 'fromManager', 'fromDiscipline', 'voided', 'cancelled']) {
              delete out[key];
              if (old && old[key] !== undefined) out[key] = old[key];
            }
            if (field === 'attendance' && (!old || old.scoreDeduct == null)) {
              const fallback = out.type === 'late' ? 0.25 : 0.5;
              const configured = full.rules && full.rules[out.type];
              const score = configured == null ? fallback : Math.max(0, Number(configured) || 0);
              const dayKey = String(out.studentId) + '|' + String(out.date);
              out.scoreDeduct = out.type === 'absent' && chargedAbsentDays.has(dayKey) ? 0 : score;
              if (out.type === 'absent' && out.scoreDeduct > 0) chargedAbsentDays.add(dayKey);
            }
            if (field === 'submissions') out.status = old ? old.status : 'pending';
            return out;
          });
        }
      }
      if (clean.staffSelfUpdate) {
        if (String(clean.staffSelfUpdate.id) !== viewer.staffId) return json(res, { ok: false, error: 'forbidden' }, 403);
      }
      if (clean.messages) clean.messages = clean.messages.filter(m => {
        const old = (full.messages || []).find(x => x.id === m.id);
        return !old || messageVisible(old, viewer);
      }).map(m => {
        const old = (full.messages || []).find(x => x.id === m.id);
        if (old && String(old.fromId) !== viewer.staffId) {
          const key = viewer.role + ':' + viewer.staffId;
          return Array.isArray(m.readBy) && m.readBy.includes(key)
            ? Object.assign({}, old, { readBy: [...new Set([...(old.readBy || []), key])] }) : old;
        }
        return Object.assign({}, m, { fromId: viewer.staffId, fromRole: viewer.role, fromKey: viewer.role + ':' + viewer.staffId });
      });
      for (const [field, deleted] of [['attendance', 'deletedAttendanceIds'], ['submissions', 'deletedSubmissionIds'], ['students', 'deletedStudentIds'], ['classMessages', 'deletedClassMessageIds'], ['disciplinePhotos', 'deletedDisciplinePhotoIds'], ['exams', 'deletedExamIds'], ['messages', 'deletedMessageIds'], ['teacherNotes', 'deletedTeacherNoteIds'], ['sampleQuestions', 'deletedSampleQuestionIds']]) {
        if (clean[deleted]) clean[deleted] = clean[deleted].filter(id => (scoped[field] || []).some(x => String(x.id) === String(id) && (viewer.role !== 'teacher' || String(x.teacherId || x.fromId || '') === viewer.staffId)));
      }
      if (clean.deletedAttendanceKeys) {
        clean.deletedAttendanceKeys = clean.deletedAttendanceKeys.filter(key => [...studentIds].some(sid =>
          String(key).startsWith('day:' + sid + ':') || String(key).startsWith('per:' + sid + ':')) ||
          (scoped.attendance || []).some(a => String(key) === 'id:' + a.id || String(key).startsWith('sub:' + a.submissionId + ':' + a.studentId + ':')));
      }
      if (clean.classMessages) {
        const visible = new Map((scoped.classMessages || []).map(m => [String(m.id), m]));
        const key = viewer.role + ':' + viewer.staffId;
        clean.classMessages = clean.classMessages.flatMap(m => {
          const old = (full.classMessages || []).find(x => String(x.id) === String(m.id));
          if (viewer.role === 'teacher') {
            // A recipient may acknowledge only their own message, never edit or create it.
            if (!old || !visible.has(String(m.id)) || !Array.isArray(m.readBy) || !m.readBy.includes(key)) return [];
            return [Object.assign({}, old, { readBy: [...new Set([...(old.readBy || []), key])] })];
          }
          if (!classIds.has(String(m.classId)) || (old && !visible.has(String(m.id)))) return [];
          const student = (scoped.students || []).find(x => String(x.id) === String(m.studentId));
          const teacher = (full.staff || []).find(x => String(x.id) === String(m.teacherId) && normalizeRole(x.role) === 'teacher');
          if (!student || String(student.classId) !== String(m.classId) || !teacher ||
              !(full.assignments || []).some(a => String(a.classId) === String(m.classId) && assignmentIsMine(a, teacher.id, teacher.username))) return [];
          return [Object.assign({}, m, { toKey: 'teacher:' + teacher.id })];
        });
      }
      if (clean.disciplinePhotos) clean.disciplinePhotos = clean.disciplinePhotos.filter(photo => {
        const old = (full.disciplinePhotos || []).find(x => String(x.id) === String(photo.id));
        const student = (scoped.students || []).find(x => String(x.id) === String(photo.studentId));
        return owns(photo) && (!old || owns(old)) && student && String(student.classId) === String(photo.classId);
      });
      if (clean.students) {
        clean.students = clean.students.filter(s => classIds.has(String(s.classId)) &&
          (!(full.students || []).some(x => String(x.id) === String(s.id)) || studentIds.has(String(s.id))));
      }
      // Deputy student edits are deltas: preserve the other shift's structure.
      if (p.endsWith('/structure')) {
        clean.students = mergeById(full.students || [], clean.students || []);
        clean.students = filterOutByIds(clean.students, clean.deletedStudentIds || []);
      }
      req.body = clean;
    }
    if (match && req.method !== 'GET' && !manager && /\/submissions$/.test(p)) {
      const full = loadAppData(schoolId);
      const scoped = scopeAppDataForViewer(full, viewerQuery(req));
      const old = (full.submissions || []).find(x => String(x.id) === String(req.body.id));
      if (old && (viewer.role === 'teacher' && String(old.teacherId) !== viewer.staffId)) return json(res, { ok: false, error: 'forbidden' }, 403);
      const incoming = req.method === 'DELETE' ? (full.submissions || []).find(x => x.id === req.body.id) : req.body;
      if (!incoming || !(scoped.classes || []).some(c => String(c.id) === String(incoming.classId)) ||
          (viewer.role === 'teacher' && String(incoming.teacherId || '') !== viewer.staffId)) {
        return json(res, { ok: false, error: 'forbidden' }, 403);
      }
      if (viewer.role === 'teacher' && req.method !== 'DELETE') {
        if (req.body.assignId && !(scoped.assignments || []).some(a => String(a.id) === String(req.body.assignId))) return json(res, { ok: false, error: 'forbidden' }, 403);
        const studentIds = new Set((scoped.students || []).map(x => String(x.id)));
        if (Array.isArray(req.body.rows)) req.body.rows = req.body.rows.filter(row => studentIds.has(String(row.studentId)));
        req.body.status = 'pending';
        for (const key of ['reviewedAt', 'reviewedBy', 'voided', 'cancelled', 'archived']) delete req.body[key];
      }
    }
    return next();
  } catch (e) {
    return json(res, { ok: false, error: 'invalid_request' }, 400);
  }
}

function classMessageForTeacher(message, staffId) {
  const key = 'teacher:' + String(staffId);
  return message.teacherId
    ? String(message.teacherId) === String(staffId) && (!message.toKey || message.toKey === key)
    : message.toKey === key;
}

function messageVisible(message, viewer) {
  return String(message.fromId) === viewer.staffId || String(message.toId) === viewer.staffId ||
    String(message.toId) === viewer.role + ':' + viewer.staffId ||
    String(message.toId) === (viewer.role === 'teacher' ? 'all_teachers' : 'all_deputies') ||
    (!message.toId && String(message.toRole) === viewer.role);
}

function loadSchoolRow(id) {
  const row = db.prepare('SELECT id, code, manager_username, data, updated_at FROM schools WHERE id = ?').bind(id).first();
  if (!row) return null;
  try {
    const data = JSON.parse(row.data || '{}');
    return Object.assign({}, data, { id: row.id, code: row.code || data.code, updatedAtMs: row.updated_at });
  } catch (e) {
    return { id: row.id, code: row.code };
  }
}

function saveSchoolRow(school) {
  const id = String(school.id || '');
  if (!id) throw new Error('school id required');
  const code = String(school.code || '');
  const managerUsername = String(school.managerUsername || school.managerUser || '');
  const data = JSON.stringify(school);
  const now = Date.now();
  db.prepare(
    `INSERT INTO schools (id, code, manager_username, data, updated_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET code = excluded.code, manager_username = excluded.manager_username,
       data = excluded.data, updated_at = excluded.updated_at`
  ).bind(id, code, managerUsername, data, now).run();
}

function loadAppData(schoolId) {
  const row = db.prepare('SELECT data, updated_at FROM app_data WHERE school_id = ?').bind(schoolId).first();
  if (!row) return { _hadRow: false, classes: [], students: [], staff: [], assignments: [], attendance: [], submissions: [] };
  try {
    const data = JSON.parse(row.data || '{}');
    data._hadRow = true;
    data.updatedAtMs = row.updated_at;
    return data;
  } catch (e) {
    return { _hadRow: true, classes: [], students: [], staff: [], assignments: [], attendance: [] };
  }
}

function saveAppData(schoolId, data, request) {
  return sqlite.transaction(() => {
  const payload = Object.assign({}, data);
  delete payload._hadRow;
  delete payload._fromCache;
  for (const key of ['auth', '_compatNoAuth', '_motherPanel', 'managerAuthority', 'deputyAuthority', 'confirmStructureWrite', 'replaceStructure', 'replaceAssignments', 'structureWriteToken', '_fullRestore', '_bypassPerfFilter', '_softOnly', '_partialDelta', 'clearStructure']) delete payload[key];
  payload.resetYear = false;
  payload.clearPerformance = false;
  const prior = db.prepare('SELECT data, updated_at FROM app_data WHERE school_id = ?').bind(schoolId).first();
  const notebook = prior ? JSON.parse(prior.data || '{}') : {};
  payload.teacherNotes = Array.isArray(notebook.teacherNotes) ? notebook.teacherNotes : [];
  payload.deletedTeacherNoteIds = notebook.deletedTeacherNoteIds || [];
  payload._teacherNoteDeletionOwners = Object.assign({}, notebook._teacherNoteDeletionOwners || {});
  if (request && request.viewer.role === 'teacher') {
    const body = request.body || {};
    const staffId = request.viewer.staffId;
    const deletions = (body.deletedTeacherNoteIds || []).filter(id => payload.teacherNotes.some(n =>
      String(n.id) === String(id) && String(n.teacherId || '') === staffId));
    for (const id of deletions) payload._teacherNoteDeletionOwners[String(id)] = staffId;
    payload.deletedTeacherNoteIds = mergeDeletedIds(payload.deletedTeacherNoteIds, deletions);
    // A notebook is not attendance: reset dates must not discard old/offline notes.
    payload.teacherNotes = filterOutByIds(mergeById(payload.teacherNotes, body.teacherNotes || []), payload.deletedTeacherNoteIds);
  }
  payload.updatedAtMs = Math.max(Date.now(), (Number(prior && prior.updated_at) || 0) + 1);
  const str = JSON.stringify(payload);
  db.prepare(
    `INSERT INTO app_data (school_id, data, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(school_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`
  ).bind(schoolId, str, payload.updatedAtMs).run();
  const school = loadSchoolRow(schoolId);
  if (school && payload.managerUser && payload.managerPass) {
    school.managerUsername = payload.managerUser;
    school.managerPassword = payload.managerPass;
    delete school.managerUser;
    delete school.managerPass;
    saveSchoolRow(school);
  }
  const clearedAt = Number(payload._performanceClearedAt) || 0;
  if (clearedAt) db.prepare('DELETE FROM submissions WHERE school_id = ? AND created_at <= ?').bind(schoolId, clearedAt).run();
  for (const id of payload.deletedSubmissionIds || []) {
    db.prepare('DELETE FROM submissions WHERE school_id = ? AND id = ?').bind(schoolId, String(id)).run();
  }
  for (const sub of payload.submissions || []) {
    if (!sub || !sub.id) continue;
    db.prepare('UPDATE submissions SET data = ? WHERE school_id = ? AND id = ?')
      .bind(JSON.stringify(sub), schoolId, String(sub.id)).run();
  }
  })();
}

/** بعد از بازنشانی سال: رکوردهای قدیمی عملکرد را نپذیر (جلوگیری از پر شدن دوباره توسط مرورگر دیگر) */
function filterPostResetPerformance(prev, incomingList, body) {
  // فقط بکاپ کامل عمدی — نه هر structure write با confirmStructureWrite
  if (body && (body._fullRestore === true || body._bypassPerfFilter === true)) {
    return incomingList;
  }
  const clearedAt = Number(prev && prev._performanceClearedAt) || 0;
  if (!clearedAt || !Array.isArray(incomingList)) return incomingList;
  return incomingList.filter((x) => {
    if (!x) return false;
    let t = Number(x.createdAtMs) || Number(x.createdAt) || 0;
    // اگر معلم همین الان فرستاده و timestamp نداشت، از updatedAtMs بدنه استفاده کن

    if (!t) return false;
    return t > clearedAt;
  });
}

function mergeAuxiliary(prev, body, next) {
  const reset = body.resetYear === true || body.clearPerformance === true;
  if (!reset) {
    for (const field of ['teacherNotes', 'exams', 'messages', 'classMessages']) {
      if (Array.isArray(body[field])) next[field] = mergeListSafe(prev, field, body[field], body);
    }
  }
  for (const field of ['sampleQuestions', 'disciplinePhotos']) {
    if (Array.isArray(body[field])) next[field] = mergeById(prev[field], body[field]);
  }
  for (const field of ['rules', 'absentSmsSent', 'classMsgTemplates']) {
    if (body[field] && typeof body[field] === 'object' && !Array.isArray(body[field])) next[field] = Object.assign({}, prev[field] || {}, body[field]);
  }
  for (const field of ['disciplineTypes', 'smsTemplates', 'colleagues']) {
    if (Array.isArray(body[field])) next[field] = body[field];
  }
  return applySoftDeletes(next, body);
}

function sameAttendanceEvent(a, b) {
  return !!(a.submissionId && b.submissionId && String(a.submissionId) === String(b.submissionId) &&
    String(a.studentId) === String(b.studentId) && String(a.teacherId) === String(b.teacherId) &&
    String(a.date) === String(b.date) && String(a.type || 'absent') === String(b.type || 'absent'));
}
function mergeAttendanceSafe(prev, incoming, body) {
  const deleted = new Set((prev.deletedSubmissionIds || []).map(String));
  const filtered = filterPostResetPerformance(prev, incoming, body).filter(x => !x.submissionId || !deleted.has(String(x.submissionId)));
  return propagateExcusedSameDay(mergeById(prev.attendance || [], filtered));
}

function mergeListSafe(prev, field, incoming, body) {
  const filtered = filterPostResetPerformance(prev, incoming, body);
  return mergeById(prev[field] || [], filtered);
}

function mergeById(prevList, incoming) {
  const map = Object.create(null);
  (Array.isArray(prevList) ? prevList : []).forEach((x) => {
    if (x && x.id) map[String(x.id)] = x;
  });
  if (Array.isArray(incoming)) {
    incoming.forEach((x) => {
      if (!x || !x.id) return;
      const old = map[String(x.id)];
      if (!old) {
        map[String(x.id)] = Object.assign({}, x);
        return;
      }
      const merged = Object.assign({}, old, x);
      // موجه بودن را از هر طرف که ست شده حفظ کن (race دو موجه هم‌زمان)
      if (old.excused || x.excused) merged.excused = true;
      if (old.justified || x.justified) merged.justified = true;
      if (old.scoreLocked || x.scoreLocked) merged.scoreLocked = true;
      if (old.fromDiscipline || x.fromDiscipline) merged.fromDiscipline = true;
      if (old.fromManager || x.fromManager) merged.fromManager = true;
      (function () {
        const rank = { voided: 4, cancelled: 4, done: 3, reviewed: 3, archived: 2, pending: 1 };
        const os = String(old.status || 'pending');
        const ns = String(x.status || merged.status || 'pending');
        const or = rank[os] || 0;
        const nr = rank[ns] || 0;
        if (or > nr) {
          merged.status = old.status;
          if (old.reviewedAt) merged.reviewedAt = old.reviewedAt;
          if (old.reviewedBy) merged.reviewedBy = old.reviewedBy;
          if (old.voided) merged.voided = true;
          if (old.cancelled) merged.cancelled = true;
        } else if (old.reviewedAt && (!x.reviewedAt || Number(old.reviewedAt) >= Number(x.reviewedAt || 0))) {
          merged.reviewedAt = old.reviewedAt;
          if (old.reviewedBy) merged.reviewedBy = old.reviewedBy;
        }
      })();
      if (Array.isArray(old.readBy) || Array.isArray(x.readBy)) {
        const rb = {};
        (old.readBy || []).forEach(function (k) { if (k) rb[String(k)] = true; });
        (x.readBy || []).forEach(function (k) { if (k) rb[String(k)] = true; });
        merged.readBy = Object.keys(rb);
      }
      if ((x.sortOrder == null || x.sortOrder === '') && old.sortOrder != null && old.sortOrder !== '') {
        merged.sortOrder = old.sortOrder;
      }
      if (x.typeName) merged.typeName = x.typeName;
      else if (old.typeName) merged.typeName = old.typeName;
      if (merged.excused || merged.justified) {
        if (parseFloat(x.scoreDeduct) === 0 || parseFloat(old.scoreDeduct) === 0 || x.excused || old.excused) {
          merged.scoreDeduct = 0;
        }
      }
      // کسر قفل‌شده انضباطی را از دست نده
      if (merged.scoreLocked) {
        const sa = parseFloat(old.scoreDeduct);
        const sb = parseFloat(x.scoreDeduct);
        if (x.scoreLocked && !isNaN(sb)) merged.scoreDeduct = sb;
        else if (old.scoreLocked && !isNaN(sa) && (x.scoreDeduct == null || isNaN(sb))) merged.scoreDeduct = sa;
      }
      // عکس: خالی روی یکی، عکس طرف دیگر را پاک نکند
      // عکس: رشته خالی از کلاینت/slim نباید عکس سرور را پاک کند
      if (!(x.photo) && (old.photo)) merged.photo = old.photo;
      if (!(x.image) && (old.image)) merged.image = old.image;
      if (x._noFile && old.fileData) merged.fileData = old.fileData;
      if (x.photo === '' && old.photo) merged.photo = old.photo;
      if (x.image === '' && old.image) merged.image = old.image;
      // Legacy metadata-only empties preserve photos. An explicit newer edit may remove all photos.
      const oldPhotosAt = Number(old._photosUpdatedAt) || 0;
      const newPhotosAt = Number(x._photosUpdatedAt) || 0;
      if (newPhotosAt && newPhotosAt >= oldPhotosAt && Array.isArray(x.photos)) merged.photos = x.photos;
      else if (oldPhotosAt) { merged.photos = old.photos || []; merged._photosUpdatedAt = oldPhotosAt; }
      else if (Array.isArray(x.photos) && x.photos.length) merged.photos = x.photos;
      else if (Array.isArray(old.photos) && old.photos.length) merged.photos = old.photos;
      // پیام اتوماسیون: union خوانده‌شدن
      if (Array.isArray(old.readBy) || Array.isArray(x.readBy)) {
        const rs = {};
        (old.readBy || []).forEach((k) => { if (k) rs[String(k)] = true; });
        (x.readBy || []).forEach((k) => { if (k) rs[String(k)] = true; });
        merged.readBy = Object.keys(rs);
      }
      // ارسال حضور: status=done هرگز به pending برنگردد
      {
        const oldDone = old.status && old.status !== 'pending' && old.status !== 'voided';
        const xDone = x.status && x.status !== 'pending' && x.status !== 'voided';
        const oldVoid = !!(old.voided || old.cancelled || old.status === 'voided');
        const xVoid = !!(x.voided || x.cancelled || x.status === 'voided');
        if (oldVoid || xVoid) {
          merged.status = 'voided';
          merged.voided = true;
          merged.cancelled = true;
        } else if (oldDone || xDone) {
          if (oldDone && !xDone) {
            merged.status = old.status || 'done';
            if (old.reviewedAt) merged.reviewedAt = old.reviewedAt;
            if (old.reviewedBy) merged.reviewedBy = old.reviewedBy;
          } else if (xDone && !oldDone) {
            merged.status = x.status || 'done';
            if (x.reviewedAt) merged.reviewedAt = x.reviewedAt;
            if (x.reviewedBy) merged.reviewedBy = x.reviewedBy;
          } else {
            const ot = Number(old.reviewedAt) || 0;
            const xt = Number(x.reviewedAt) || 0;
            if (ot >= xt) {
              merged.status = old.status || 'done';
              merged.reviewedAt = old.reviewedAt || x.reviewedAt;
              merged.reviewedBy = old.reviewedBy || x.reviewedBy;
            } else {
              merged.status = x.status || 'done';
              merged.reviewedAt = x.reviewedAt || old.reviewedAt;
              merged.reviewedBy = x.reviewedBy || old.reviewedBy;
            }
          }
          if (old.archived || x.archived) {
            merged.archived = true;
            merged.archivedAt = Math.max(Number(old.archivedAt) || 0, Number(x.archivedAt) || 0) || old.archivedAt || x.archivedAt;
          }
        }
      }
      // ترتیب دانش‌آموز بر اساس _orderUpdatedAt
      if (old.sortOrder != null || x.sortOrder != null) {
        const oOrd = old.sortOrder != null ? Number(old.sortOrder) : null;
        const xOrd = x.sortOrder != null ? Number(x.sortOrder) : null;
        if (oOrd != null && xOrd != null && oOrd !== xOrd) {
          const oOu = Number(old._orderUpdatedAt) || 0;
          const xOu = Number(x._orderUpdatedAt) || 0;
          if (oOu > xOu) merged.sortOrder = oOrd;
          else if (xOu > oOu) merged.sortOrder = xOrd;
        } else if (oOrd != null && xOrd == null) merged.sortOrder = oOrd;
        else if (xOrd != null && oOrd == null) merged.sortOrder = xOrd;
      }
      map[String(x.id)] = merged;
    });
  }
  return Object.keys(map).map((k) => map[k]);
}

/** اگر یک غیبت موجه شد، همه غیبت‌های همان دانش‌آموز در همان روز موجه شوند */
function propagateExcusedSameDay(attendance) {
  if (!Array.isArray(attendance) || !attendance.length) return attendance || [];
  const excusedDays = {};
  attendance.forEach((a) => {
    if (!a || !a.studentId) return;
    const t = a.type || '';
    if (t !== 'absent' && t !== 'late') return;
    if (!(a.excused || a.justified || (parseFloat(a.scoreDeduct) === 0 && a.scoreLocked))) return;
    const day = String(a.date || '').slice(0, 10);
    if (!day) return;
    excusedDays[String(a.studentId) + '|' + day] = true;
  });
  if (!Object.keys(excusedDays).length) return attendance;
  return attendance.map((a) => {
    if (!a || !a.studentId) return a;
    const t = a.type || '';
    if (t !== 'absent' && t !== 'late') return a;
    const day = String(a.date || '').slice(0, 10);
    if (!excusedDays[String(a.studentId) + '|' + day]) return a;
    if (a.excused && a.justified && parseFloat(a.scoreDeduct) === 0) return a;
    const out = Object.assign({}, a);
    out.excused = true;
    out.justified = true;
    out.scoreDeduct = 0;
    out.scoreLocked = true;
    if ((out.note || '').indexOf('موجه') < 0) {
      out.note = (out.note ? out.note + ' · ' : '') + 'موجه';
    }
    return out;
  });
}

/** حذف آیتم‌ها بر اساس لیست شناسه‌ها */
function filterOutByIds(list, deletedIds) {
  if (!Array.isArray(list) || !list.length) return Array.isArray(list) ? list : [];
  if (!Array.isArray(deletedIds) || !deletedIds.length) return list;
  const del = {};
  deletedIds.forEach((id) => {
    if (id != null && id !== '') del[String(id)] = true;
  });
  return list.filter((x) => x && x.id && !del[String(x.id)]);
}

/** ادغام لیست شناسه‌های حذف‌شده (بدون تکرار، سقف ۵۰۰) */
function mergeDeletedIds(prevIds, incomingIds) {
  const set = {};
  (Array.isArray(prevIds) ? prevIds : []).forEach((id) => {
    if (id != null && id !== '') set[String(id)] = true;
  });
  (Array.isArray(incomingIds) ? incomingIds : []).forEach((id) => {
    if (id != null && id !== '') set[String(id)] = true;
  });
  const out = Object.keys(set);
  return out;
}

/** فیلتر حضور با کلیدهای پایدار (همیشه با type تا تأخیر≠غیبت) */
function filterAttendanceByDeletedKeys(list, keys) {
  if (!Array.isArray(list) || !list.length) return Array.isArray(list) ? list : [];
  if (!Array.isArray(keys) || !keys.length) return list;
  const dk = {};
  keys.forEach((k) => { if (k != null && k !== '') dk[String(k)] = true; });
  return list.filter((a) => {
    if (!a || !a.id) return false;
    const sid = String(a.studentId || '');
    const day = String(a.date || '');
    const typ = String(a.type || 'absent');
    const per = String(a.periodName || '');
    const sub = String(a.submissionId || '');
    if (dk['id:' + String(a.id)]) return false;
    if (sub && sid && dk['sub:' + sub + ':' + sid + ':' + typ]) return false;
    // کلید قدیمی بدون type فقط اگر type هم absent باشد اعمال نشود برای late
    // برای سازگاری: کلید بدون type فقط روی همان type=absent قدیمی‌ها
    if (sub && sid && dk['sub:' + sub + ':' + sid] && typ === 'absent') return false;
    if (sid && day && dk['day:' + sid + ':' + day + ':' + typ]) return false;
    if (sid && day && per && dk['per:' + sid + ':' + day + ':' + per + ':' + typ]) return false;
    if (sid && day && per && dk['per:' + sid + ':' + day + ':' + per] && typ === 'absent') return false;
    return true;
  });
}

/** اعمال حذف حضور و ارسال روی appData */
function applySoftDeletes(data, body) {
  const next = data || {};
  const fields = { classes: 'deletedClassIds', students: 'deletedStudentIds', staff: 'deletedStaffIds',
    assignments: 'deletedAssignmentIds', exams: 'deletedExamIds', messages: 'deletedMessageIds',
    teacherNotes: 'deletedTeacherNoteIds', sampleQuestions: 'deletedSampleQuestionIds',
    disciplinePhotos: 'deletedDisciplinePhotoIds', classMessages: 'deletedClassMessageIds' };
  for (const [field, key] of Object.entries(fields)) {
    next[key] = mergeDeletedIds(next[key], body[key]);
    if (Array.isArray(next[field])) next[field] = filterOutByIds(next[field], next[key]);
  }
  const deletedClasses = new Set(next.deletedClassIds || []);
  const deletedStudents = new Set(next.deletedStudentIds || []);
  next.students = (next.students || []).filter(x => !deletedClasses.has(String(x.classId)));
  next.assignments = (next.assignments || []).filter(x => !deletedClasses.has(String(x.classId)) && !(next.deletedStaffIds || []).includes(String(x.teacherId)));
  next.attendance = (next.attendance || []).filter(x => !deletedStudents.has(String(x.studentId)) && !deletedClasses.has(String(x.classId)));
  // شناسه‌های حذف‌شده را نگه دار تا بعداً برنگردند
  if (Array.isArray(body.deletedAttendanceIds) && body.deletedAttendanceIds.length) {
    next.deletedAttendanceIds = mergeDeletedIds(next.deletedAttendanceIds, body.deletedAttendanceIds);
  }
  if (Array.isArray(body.deletedAttendanceKeys) && body.deletedAttendanceKeys.length) {
    next.deletedAttendanceKeys = mergeDeletedIds(next.deletedAttendanceKeys, body.deletedAttendanceKeys);
  }
  if (Array.isArray(body.deletedSubmissionIds) && body.deletedSubmissionIds.length) {
    next.deletedSubmissionIds = mergeDeletedIds(next.deletedSubmissionIds, body.deletedSubmissionIds);
  }
  // فیلتر attendance با id و کلید پایدار
  if (Array.isArray(next.deletedAttendanceIds) && next.deletedAttendanceIds.length) {
    next.attendance = filterOutByIds(next.attendance, next.deletedAttendanceIds);
  }
  if (Array.isArray(next.deletedAttendanceKeys) && next.deletedAttendanceKeys.length) {
    next.attendance = filterAttendanceByDeletedKeys(next.attendance, next.deletedAttendanceKeys);
  }
  // فیلتر submissions + attendance وابسته به submission
  if (Array.isArray(next.deletedSubmissionIds) && next.deletedSubmissionIds.length) {
    next.submissions = filterOutByIds(next.submissions, next.deletedSubmissionIds);
    const delSub = {};
    next.deletedSubmissionIds.forEach((id) => { delSub[String(id)] = true; });
    next.attendance = (Array.isArray(next.attendance) ? next.attendance : []).filter(
      (a) => !a || !a.submissionId || !delSub[String(a.submissionId)]
    );
  }
  // اگر خود رکورد voided فرستاده شده، از لیست submissions حذف کن
  if (Array.isArray(body.submissions)) {
    const voided = {};
    body.submissions.forEach((s) => {
      if (s && s.id && (s.status === 'voided' || s.voided || s.cancelled)) {
        voided[String(s.id)] = true;
      }
    });
    if (Object.keys(voided).length) {
      next.submissions = (Array.isArray(next.submissions) ? next.submissions : []).filter(
        (s) => s && s.id && !voided[String(s.id)]
      );
      next.attendance = (Array.isArray(next.attendance) ? next.attendance : []).filter(
        (a) => !a || !a.submissionId || !voided[String(a.submissionId)]
      );
      next.deletedSubmissionIds = mergeDeletedIds(next.deletedSubmissionIds, Object.keys(voided));
    }
  }
  return next;
}

// —— HTML صفحات ——
function sendHtml(res, file) {
  const p = path.join(__dirname, file);
  if (!fs.existsSync(p)) return res.status(404).send('Not found');
  try {
    const st = fs.statSync(p);
    const etag = '"' + st.size + '-' + st.mtimeMs + '"';
    res.setHeader('ETag', etag);
    // کش کوتاه: همان روز دوباره ۷۰۰KB دانلود نشود
    res.setHeader('Cache-Control', 'public, max-age=120, must-revalidate');
    if (res.req && res.req.headers['if-none-match'] === etag) {
      return res.status(304).end();
    }
    const buf = fs.readFileSync(p);
    return sendGzipBuffer(res.req || {}, res, buf, 'text/html; charset=utf-8', 'public, max-age=120, must-revalidate');
  } catch (e) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.sendFile(p);
  }
}

function pageForHost(req) {
  const host = String(req.hostname || req.headers.host || '').toLowerCase().split(':')[0];
  if (host.startsWith('teacher.') || host.startsWith('parents.')) return 'parents.html';
  if (host.startsWith('admin.') || host.includes('admin.nikan')) return 'mother.html';
  if (host.startsWith('panel.') || host.includes('panel.nikan')) return 'school.html';
  return null; // دامنه ناشناس → صفحه انتخاب
}

app.get('/', (req, res) => {
  const file = pageForHost(req);
  if (file) return sendHtml(res, file);
  return sendHtml(res, 'home.html');
});
app.get('/mother', (req, res) => sendHtml(res, 'mother.html'));
app.get('/index.html', (req, res) => {
  const file = pageForHost(req) || 'school.html';
  return sendHtml(res, file);
});
app.get('/school', (req, res) => sendHtml(res, 'school.html'));
app.get('/parents', (req, res) => sendHtml(res, 'parents.html'));
app.get('/parents.html', (req, res) => sendHtml(res, 'parents.html'));
app.get('/panel-theme.css', (req,res) => res.type('text/css').sendFile(path.join(__dirname,'panel-theme.css')));
app.get('/panel-appearance.js', (req,res) => res.type('application/javascript').sendFile(path.join(__dirname,'panel-appearance.js')));
app.get('/parent-school.js', (req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'parent-school.js')));
app.get('/parent-branding.js', (req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'lib/parent-branding.js')));
app.get('/parent-branding-client.js', (req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'parent-branding-client.js')));
app.get('/parent-branding-mother.js', (req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'parent-branding-mother.js')));
app.get('/assets/fonts/vazirmatn.woff2', (req, res) => {
  res.set('Cache-Control', 'public, max-age=604800');
  res.type('font/woff2').sendFile(path.join(__dirname, 'assets/fonts/vazirmatn.woff2'));
});

// favicon ساده
app.get('/favicon.svg', (req, res) => {
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#0f1c4d"/><text x="32" y="42" text-anchor="middle" font-size="32" font-family="Tahoma,sans-serif" font-weight="700" fill="#c9a84c">ن</text></svg>';
  res.type('image/svg+xml').send(svg);
});

app.get('/manifest.webmanifest', (req, res) => {
  res.json({
    name: 'سامانه نیکان',
    short_name: 'نیکان',
    start_url: '/school',
    display: 'standalone',
    background_color: '#0f1c4d',
    theme_color: '#0f1c4d',
    lang: 'fa',
    dir: 'rtl'
  });
});
app.get('/manifest-mother.webmanifest', (req, res) => {
  res.json({
    name: 'پنل مدیریتی سامانه نیکان',
    short_name: 'پنل مدیریت',
    start_url: '/mother',
    display: 'standalone',
    background_color: '#0f1c4d',
    theme_color: '#0f1c4d',
    lang: 'fa',
    dir: 'rtl'
  });
});

// —— Health ——
require('./parent-portal').installParentPortal(app, { sqlite, loadAppData, saveAppData, loadSchoolRow, schoolUnavailable,
  authenticateWrite, scopeAppDataForViewer, viewerQuery, applySoftDeletes, json });
app.use('/api', authorizeApi);

app.get('/api', (req, res) => json(res, { ok: true, service: 'nikan-node', time: Date.now() }));
app.get('/api/health', (req, res) => json(res, { ok: true, time: Date.now() }));

// —— Login (مدرسه) ——
app.post('/api/mother/login', (req, res) => {
  const body = req.body || {};
  const account = motherAccountState();
  if (!account.configured) return json(res, { ok: false, error: account.error }, 503);
  if (!motherCredentialsOk({ user: body.user, pass: body.pass, role: 'mother' }, account)) {
    return json(res, { ok: false, error: 'invalid_credentials' }, 401);
  }
  return json(res, { ok: true, role: 'mother' });
});

app.post('/api/mother/account', (req, res) => {
  const body = req.body || {};
  const user = String(body.user || '').trim();
  const pass = String(body.pass || '');
  if (user.length < 3 || user.length > 256 || pass.length < 6 || pass.length > 1024) return json(res, { ok: false, error: 'invalid_credentials' }, 400);
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pass, salt, 64).toString('hex');
  db.prepare('INSERT INTO app_data (school_id, data, updated_at) VALUES (?, ?, ?) ON CONFLICT(school_id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at')
    .bind('__mother_auth__', JSON.stringify({ user, salt, hash }), Date.now()).run();
  return json(res, { ok: true });
});

app.post('/api/register', (req, res) => {
  const body = req.body || {};
  const user = String(body.user || '').trim();
  const pass = String(body.pass || '');
  if (!body.name || !body.managerName || !body.phone || !user || pass.length < 6) {
    return json(res, { ok: false, error: 'required_fields' }, 400);
  }
  const duplicate = db.prepare('SELECT id FROM schools WHERE manager_username = ?').bind(user).first();
  if (duplicate) return json(res, { ok: false, error: 'username_exists' }, 409);
  const start = new Date();
  const expiry = new Date(start); expiry.setUTCDate(expiry.getUTCDate() + 30);
  const school = {
    id: crypto.randomUUID(), code: 'SCH-' + crypto.randomBytes(5).toString('hex').toUpperCase(),
    name: String(body.name).trim(), managerName: String(body.managerName).trim(), managerPhone: String(body.phone),
    city: String(body.city || ''), managerUsername: user, managerPassword: pass,
    startDate: start.toISOString().slice(0, 10), expireDate: expiry.toISOString().slice(0, 10),
    maxUsers: 15, shifts: 1, modules: ['sms', 'discipline', 'teacher_attendance'], smsMode: 'sim',
    active: true, activationUsed: true, source: 'self_register', plan: 'trial'
  };
  sqlite.transaction(() => {
    saveSchoolRow(school);
    saveAppData(school.id, { classes: [], students: [], staff: [], assignments: [], attendance: [], submissions: [],
      managerUser: user, managerPass: pass, shifts: 1 });
  })();
  return json(res, { ok: true, school: publicSchool(school) }, 201);
});

app.post('/api/activate', (req, res) => {
  const body = req.body || {};
  const row = db.prepare('SELECT id FROM schools WHERE code = ?').bind(String(body.code || '').trim()).first();
  const school = row && loadSchoolRow(row.id);
  if (!school || !school.activationCode || school.activationUsed ||
      !safeEqual(body.activationCode || '', school.activationCode)) {
    return json(res, { ok: false, error: 'invalid_activation' }, 401);
  }
  const unavailable = schoolUnavailable(school);
  if (unavailable) return json(res, { ok: false, error: unavailable }, 403);
  // Existing manager credentials must also be supplied: activation codes never expose passwords.
  const user = String(body.user || '').trim();
  const pass = String(body.pass || '');
  const auth = authenticateWrite(req, school.id, { auth: { user, pass, role: 'manager' } });
  if (!auth.ok || auth.role !== 'manager') return json(res, { ok: false, error: 'invalid_credentials' }, 401);
  school.activationUsed = true;
  saveSchoolRow(school);
  return json(res, { ok: true, school: publicSchool(school) });
});

app.post('/api/login', (req, res) => {
  try {
    const body = req.body || {};
    const user = String(body.user || '').trim();
    const pass = String(body.pass || '');
    if (!user || !pass) return json(res, { ok: false, error: 'user_pass_required' }, 400);
    const rows = body.code
      ? db.prepare('SELECT id FROM schools WHERE code = ?').bind(String(body.code).trim()).all().results
      : db.prepare('SELECT id FROM schools WHERE manager_username = ?').bind(user).all().results;
    for (const row of rows) {
      const viewer = authenticateWrite(req, row.id, { auth: { user, pass, role: body.role || 'manager' } });
      if (!viewer.ok || viewer.role === 'mother') continue;
      if (body.role && normalizeRole(body.role) !== viewer.role) continue;
      return json(res, { ok: true, role: viewer.role, staffId: viewer.staffId,
        school: authenticatedSchool(loadSchoolRow(row.id), viewer.role) });
    }
    return json(res, { ok: false, error: 'invalid_credentials' }, 401);
  } catch (e) {
    return json(res, { ok: false, error: 'server_error' }, 500);
  }
});

// —— School by code ——
app.get('/api/schools/by-code/:code', (req, res) => {
  try {
    const code = String(req.params.code || '').trim();
    const row = db.prepare('SELECT id, code, data FROM schools WHERE code = ? LIMIT 1').bind(code).first();
    if (!row) return json(res, { ok: false, error: 'not_found' }, 404);
    let school = {};
    try { school = JSON.parse(row.data || '{}'); } catch (e) {}
    school.id = row.id;
    school.code = row.code || school.code;
    // رمز را برنگردان در پاسخ عمومی
    const safe = publicSchool(school);
    return json(res, { ok: true, school: safe });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Schools list ——
app.get('/api/schools', (req, res) => {
  try {
    // فقط مادر یا با کلید مادر اجازه دیدن لیست کامل را دارد
    // (کلاینت‌های قدیمی که این endpoint را صدا می‌زنند لیست خالی امن می‌گیرند)
    const body = req.body || {};
    const roleHdr = req.viewer.role;
    const isMother =
      roleHdr === 'mother' ||
      body._motherPanel === true ||
      body._compatNoAuth === true ||
      motherKeyOk(req);
    if (!isMother) {
      return json(res, { ok: true, schools: [], restricted: true });
    }
    ensureSchema();
    const { results } = db.prepare('SELECT id, code, manager_username, data, updated_at FROM schools ORDER BY updated_at DESC').bind().all();
    const schools = (results || []).map((r) => {
      try {
        const d = JSON.parse(r.data || '{}');
        const safe = Object.assign({}, d, { id: r.id, code: r.code || d.code, updatedAtMs: r.updated_at });
        // هرگز رمز را در لیست برنگردان
        return safe;
      } catch (e) {
        return { id: r.id, code: r.code };
      }
    });
    return json(res, { ok: true, schools });
  } catch (e) {
    console.error(e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Create / update school ——
app.post('/api/schools', async (req, res) => {
  try {
    const body = req.body || {};
    // سازگاری با پنل مادر حفظ می‌شود؛ در غیر این صورت باید auth معتبر باشد
    const allowedByCompat = req.viewer.role === 'mother';
    if (!allowedByCompat) {
      const auth = await authenticateWrite(req, body.id || '', body);
      if (!auth.ok) {
        return json(res, { ok: false, error: auth.error || 'auth_required' }, 401);
      }
      // فقط مادر یا مدیر همان مدرسه می‌تواند ایجاد/ویرایش کند
      if (auth.role !== 'mother' && auth.role !== 'manager') {
        return json(res, { ok: false, error: 'forbidden' }, 403);
      }
    }
    const previous = body.id ? loadSchoolRow(String(body.id)) : null;
    if (req.viewer.role !== 'mother' && !previous) return json(res, { ok: false, error: 'forbidden' }, 403);
    const permitted = req.viewer.role === 'mother' ? Object.assign({}, body) : {};
    if (req.viewer.role !== 'mother') {
      for (const key of ['name', 'managerName', 'managerPhone', 'city', 'managerUsername', 'managerPassword', 'managerUser', 'managerPass']) {
        if (body[key] !== undefined) permitted[key] = body[key];
      }
    }
    const school = Object.assign({}, previous || {}, permitted);
    for (const key of ['managerPassword', 'managerPass']) {
      if (!school[key] && previous && previous[key]) school[key] = previous[key];
    }
    if (!school.code || !school.name || !(school.managerUsername || school.managerUser) || !(school.managerPassword || school.managerPass)) {
      return json(res, { ok: false, error: 'school_fields_required' }, 400);
    }
    const duplicate = db.prepare('SELECT id FROM schools WHERE (code = ? OR manager_username = ?) AND id != ?')
      .bind(String(school.code), String(school.managerUsername || school.managerUser), String(school.id || '')).first();
    if (duplicate) return json(res, { ok: false, error: 'school_code_or_username_exists' }, 409);
    delete school.auth;
    delete school._compatNoAuth;
    delete school._motherPanel;
    if (!school.id) school.id = 'id_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    school.updatedAtMs = Date.now();
    sqlite.transaction(() => {
      saveSchoolRow(school);
      const data = loadAppData(school.id);
      data.managerUser = school.managerUsername || school.managerUser;
      data.managerPass = school.managerPassword || school.managerPass;
      saveAppData(school.id, data);
    })();
    return json(res, { ok: true, school: { id: school.id, code: school.code } });
  } catch (e) {
    console.error(e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Delete school ——
app.delete('/api/schools/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    // فقط مادر (با کلید یا فلگ سازگاری پنل مادر) اجازه حذف کامل مدرسه را دارد
    let isAllowed = req.viewer.role === 'mother';
    if (!isAllowed) {
      const auth = await authenticateWrite(req, id, body);
      isAllowed = auth.ok && auth.role === 'mother';
    }
    if (!isAllowed) {
      return json(res, { ok: false, error: 'auth_required', message: 'only mother can delete school' }, 401);
    }
    sqlite.transaction(() => {
    db.prepare('DELETE FROM schools WHERE id = ?').bind(id).run();
    db.prepare('DELETE FROM app_data WHERE school_id = ?').bind(id).run();
    db.prepare('DELETE FROM submissions WHERE school_id = ?').bind(id).run();
    db.prepare('DELETE FROM attendance_records WHERE school_id = ?').bind(id).run();
    db.prepare('DELETE FROM school_soft_meta WHERE school_id = ?').bind(id).run();
    })();
    return json(res, { ok: true, deleted: id });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Get one school ——
app.get('/api/schools/:id', (req, res) => {
  try {
    const school = loadSchoolRow(req.params.id);
    if (!school) return json(res, { ok: false, error: 'school_not_found' }, 404);
    // رمز مدیر را هرگز در پاسخ عمومی برنگردان
    const safe = authenticatedSchool(school, req.viewer.role);
    return json(res, { ok: true, school: safe });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— appData GET ——

/** شیفت کلاس/پرسنل را به 1 (صبح) یا 2 (عصر) نرمال کن */
function normShiftVal(v) {
  if (v == null || v === '') return 0;
  const n = parseInt(v, 10);
  if (n === 1 || n === 2) return n;
  const t = String(v).trim();
  if (/صبح|morning|am/i.test(t)) return 1;
  if (/عصر|شب|evening|pm/i.test(t)) return 2;
  return 0;
}

function staffMatchesId(st, staffId, username) {
  if (!st) return false;
  if (staffId && String(st.id) === String(staffId)) return true;
  if (username && String(st.username || '').toLowerCase() === String(username).toLowerCase()) return true;
  return false;
}

function assignmentIsMine(a, staffId, username) {
  if (!a) return false;
  const sid = staffId != null && staffId !== '' ? String(staffId) : '';
  const rawIds = [a.teacherId, a.teacherId2, a.teacherId3, a.staffId, a.teacher_id, a.userId];
  const ids = rawIds.filter((x) => x != null && x !== '').map(String);
  if (sid) {
    if (ids.indexOf(sid) >= 0) return true;
    // مقایسه عددی (12 === "12")
    const sidNum = Number(sid);
    if (Number.isFinite(sidNum) && ids.some((id) => Number(id) === sidNum)) return true;
  }
  const uname = username ? String(username).toLowerCase().trim() : '';
  if (uname) {
    const names = [a.teacherName, a.teacherUsername, a.username, a.teacher, a.name]
      .filter(Boolean)
      .map((x) => String(x).toLowerCase().trim());
    if (names.indexOf(uname) >= 0) return true;
  }
  return false;
}

/**
 * محدودسازی داده برای معلم / معاون — مدیر کل را می‌گیرد
 * query: scope=mine&role=teacher|deputy&staffId=&user=
 */
function scopeAppDataForViewer(full, query) {
  if (!full || typeof full !== 'object') return full;
  const scope = String((query && query.scope) || '').toLowerCase();
  if (scope !== 'mine') {
    const out = Object.assign({}, full);
    delete out._hadRow;
    delete out._teacherNoteDeletionOwners;
    out.teacherNotes = [];
    out.deletedTeacherNoteIds = [];
    out._scoped = false;
    return out;
  }
  const role = String((query && query.role) || '').toLowerCase();
  const staffId = query && query.staffId != null ? String(query.staffId) : '';
  const username = query && (query.user || query.username) != null ? String(query.user || query.username) : '';
  const isTeacher = role === 'teacher' || role === 'معلم' || role === 'دبیر';
  const isDeputy = role === 'deputy' || role === 'معاون' || role === 'assistant';

  if (!isTeacher && !isDeputy) {
    const out = Object.assign({}, full);
    delete out._hadRow;
    delete out._teacherNoteDeletionOwners;
    out.teacherNotes = [];
    out.deletedTeacherNoteIds = [];
    out._scoped = false;
    return out;
  }

  const staffList = Array.isArray(full.staff) ? full.staff : [];
  const me = staffList.find((st) => staffMatchesId(st, staffId, username)) || null;
  const myShift = me ? normShiftVal(me.shift) : 0;

  let classIds = {};
  let assignments = Array.isArray(full.assignments) ? full.assignments.slice() : [];

  if (isTeacher) {
    const tid = staffId || (me && me.id) || '';
    const tun = username || (me && me.username) || (me && me.name) || '';
    assignments = assignments.filter((a) => assignmentIsMine(a, tid, tun));
    // اگر با staffId چیزی پیدا نشد، با نام معلم در staff دوباره تلاش کن
    if (!assignments.length && me && me.name) {
      assignments = (Array.isArray(full.assignments) ? full.assignments : []).filter((a) =>
        assignmentIsMine(a, tid, String(me.name))
      );
    }
    assignments.forEach((a) => {
      if (a && a.classId) classIds[String(a.classId)] = true;
    });
  } else {
    // معاون: کلاس‌های شیفت خودش
    (Array.isArray(full.classes) ? full.classes : []).forEach((c) => {
      if (!c || !c.id) return;
      const cs = normShiftVal(c.shift);
      if (!myShift || !cs || cs === myShift) classIds[String(c.id)] = true;
    });
    assignments = assignments.filter((a) => a && a.classId && classIds[String(a.classId)]);
  }

  const classes = (Array.isArray(full.classes) ? full.classes : []).filter((c) => c && classIds[String(c.id)]);
  const students = (Array.isArray(full.students) ? full.students : []).filter(
    (st) => st && st.classId && classIds[String(st.classId)]
  );
  const studentIds = {};
  students.forEach((st) => {
    if (st && st.id) studentIds[String(st.id)] = true;
  });

  const attendance = (Array.isArray(full.attendance) ? full.attendance : []).filter((a) => {
    if (!a) return false;
    // معلم موارد موجه را نبیند
    if (isTeacher && (a.excused || a.justified || (parseFloat(a.scoreDeduct) === 0 && a.scoreLocked && (a.note || '').indexOf('موجه') >= 0))) {
      return false;
    }
    if (a.classId && classIds[String(a.classId)]) return true;
    if (a.studentId && studentIds[String(a.studentId)]) return true;
    return false;
  });

  let submissions = Array.isArray(full.submissions) ? full.submissions : [];
  if (isTeacher) {
    submissions = submissions.filter(
      (s) =>
        s &&
        s.classId && classIds[String(s.classId)]
    );
  } else {
    submissions = submissions.filter((s) => s && s.classId && classIds[String(s.classId)]);
  }

  const exams = (Array.isArray(full.exams) ? full.exams : []).filter((e) => {
    if (!e) return false;
    if (e.classId && classIds[String(e.classId)]) return true;
    if (e.studentId && studentIds[String(e.studentId)]) return true;
    return false;
  });

  const teacherNotes = (Array.isArray(full.teacherNotes) ? full.teacherNotes : []).filter((n) => {
    if (!isTeacher || !n || String(n.teacherId || '') !== staffId) return false;
    if (n.classId) return !!classIds[String(n.classId)];
    if (n.studentId) return !!studentIds[String(n.studentId)];
    return !n.assignId || assignments.some(a => String(a.id) === String(n.assignId));
  });

  // پرسنل: فقط خود کاربر (معلم) یا همکاران هم‌شیفت (معاون) — بدون رمز بقیه
  let staffOut = [];
  if (me) {
    const self = Object.assign({}, me);
    staffOut = [self];
    if (isDeputy) {
      staffList.forEach((st) => {
        if (!st || !st.id) return;
        if (String(st.id) === String(me.id)) return;
        const ss = normShiftVal(st.shift);
        if (myShift && ss && ss !== myShift) return;
        const copy = Object.assign({}, st);
        // رمز بقیه را نفرست
        delete copy.pass;
        delete copy.password;
        staffOut.push(copy);
      });
    }
  }

  const out = Object.assign({}, full, {
    classes,
    students,
    staff: staffOut,
    assignments,
    attendance,
    submissions,
    exams,
    teacherNotes,
    colleagues: [], // دفترچه پیامک همکاران فقط برای مدیر
    messages: Array.isArray(full.messages)
      ? full.messages.filter((m) => {
          if (!m) return false;
          if (isTeacher && staffId && (String(m.toId) === String(staffId) || String(m.fromId) === String(staffId)))
            return true;
          if (isDeputy) return true;
          return String(m.toId) === 'all_teachers' || String(m.toRole) === 'teacher';
        })
      : [],
    _scoped: true,
    _scopeRole: isTeacher ? 'teacher' : 'deputy',
    _scopeStaffId: staffId || (me && me.id) || '',
    _scopeShift: myShift || 0
  });
  delete out._hadRow;
  delete out._teacherNoteDeletionOwners;
  out.deletedTeacherNoteIds = isTeacher ? (full.deletedTeacherNoteIds || []).filter(id =>
    (full._teacherNoteDeletionOwners || {})[String(id)] === staffId) : [];
  // رمز مدیر را به معلم/معاون نده
  for (const key of ['managerPass', 'managerPassword', 'managerUser', 'managerUsername', 'smsConfig', 'smsApiKey', 'absentSmsSent']) delete out[key];
  out.messageTargets=staffList.filter(st => st && st.active!==false && String(st.id)!==staffId &&
    (isDeputy || normalizeRole(st.role)==='deputy') &&
    (!myShift || !normShiftVal(st.shift) || normShiftVal(st.shift)===myShift))
    .map(st => ({id:st.id,role:normalizeRole(st.role),name:st.name||''}));
  out.messages = (full.messages || []).filter(m => messageVisible(m, { role, staffId: String(staffId) }));
  out.disciplinePhotos = isDeputy ? (full.disciplinePhotos || []).filter(x => x && studentIds[String(x.studentId)] && classIds[String(x.classId)]) : [];
  out.sampleQuestions = (full.sampleQuestions || []).filter(x => x && ((x.classId && classIds[String(x.classId)]) ||
    (isTeacher && !x.classId && !x.studentId && !x.assignId && String(x.teacherId || '') === staffId)));
  out.classMessages = (full.classMessages || []).filter(x => x && x.classId && classIds[String(x.classId)] &&
    (!isTeacher || classMessageForTeacher(x, staffId)));
  if (isDeputy) {
    const cfg = full.smsConfig || {};
    out.smsConfig = { mode: cfg.mode || 'sim', provider: cfg.provider || 'melipayamak', sender: cfg.sender || '', configured: !!(cfg.password || cfg.username) };
  }
  return out;
}

app.get('/api/schools/:id/appData', (req, res) => {
  try {
    const id = req.params.id;
    const full = req.authAppData || loadAppData(id);
    const remoteTs = Number(full.updatedAtMs) || 0;
    // since: اگر داده عوض نشده، بدنه سنگین نفرست
    const since = Number(req.query.since) || 0;
    if (since > 0 && remoteTs > 0 && remoteTs === since) {
      return json(res, { ok: true, unchanged: true, updatedAt: remoteTs });
    }
    // اگر نقش معلم/معاون در هدر باشد و scope نفرستاده، اجباری محدود کن
    const q = viewerQuery(req);
    const roleH = req.viewer.role;
    const isTeachH = roleH === 'teacher' || roleH === 'معلم' || roleH === 'دبیر';
    const isDepH = roleH === 'deputy' || roleH === 'معاون' || roleH === 'assistant';
    if (!q.scope && (isTeachH || isDepH)) {
      q.scope = 'mine';
      q.role = isDepH ? 'deputy' : 'teacher';
      if (req.headers['x-staff-id']) q.staffId = String(req.headers['x-staff-id']);
      if (req.headers['x-auth-user']) q.user = String(req.headers['x-auth-user']);
    }
    let data = scopeAppDataForViewer(full, q);

    return json(res, { ok: true, data, updatedAt: data.updatedAtMs || full.updatedAtMs || 0 });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

/**
 * بازنشانی سال تحصیلی — یک تراکنش قطعی
 * body: { keepClasses, keepStudents, keepStaff, keepAssignments, managerAuthority }
 */
app.post('/api/schools/:id/reset-year', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);
    if (!auth.ok) {
      return json(res, { ok: false, error: auth.error || 'auth_required' }, 401);
    }
    const keepC = body.keepClasses !== false;
    const keepS = body.keepStudents !== false;
    const keepT = body.keepStaff !== false;
    const keepA = body.keepAssignments === true;

    const result = sqlite.transaction(() => {
      const prev = loadAppData(id);
      const next = Object.assign({}, prev);
      const beforeAtt = Array.isArray(prev.attendance) ? prev.attendance.length : 0;
      const beforeSub = Array.isArray(prev.submissions) ? prev.submissions.length : 0;

      // عملکرد همیشه خالی — بدون استثنا
      const clearedAt = Date.now();
      next.attendance = [];
      next.submissions = [];
      next.exams = [];
      next.messages = [];
      next.teacherNotes = [];
      next.deletedExamIds = [];
      next.deletedMessageIds = [];
      next.deletedTeacherNoteIds = [];
      next.sampleQuestions = Array.isArray(prev.sampleQuestions) ? prev.sampleQuestions : [];
      next.absentSmsSent = {};
      next.deletedAttendanceIds = [];
      next.deletedSubmissionIds = [];
      next.deletedAttendanceKeys = [];
      next.resetYear = false;
      next.clearPerformance = false;
      next._performanceClearedAt = clearedAt;
      next._performanceEpoch = (Number(prev._performanceEpoch) || 0) + 1;
      next._blockSubRebuildUntil = clearedAt + 48 * 3600 * 1000;
      next.updatedAtMs = clearedAt;
      next._guard = 'node-reset-year-endpoint';

      if (!keepC) next.classes = [];
      if (!keepS) next.students = [];
      if (!keepT) {
        next.staff = [];
        next.colleagues = [];
      }
      if (!keepC) { next.students = []; next.assignments = []; }
      if (!keepT) next.assignments = [];
      if (!keepA) {
        next.assignments = [];
        next.deletedAssignmentIds = Array.isArray(prev.assignments)
          ? prev.assignments.map((a) => a && a.id).filter(Boolean).map(String)
          : [];
      }

      saveAppData(id, mergeAuxiliary(prev, body, next));

      // دوباره بخوان و اگر هنوز پر بود زورکی خالی کن
      let check = loadAppData(id);
      if ((check.attendance || []).length > 0 || (check.submissions || []).length > 0) {
        check.attendance = [];
        check.submissions = [];
        check.exams = [];
        check.messages = [];
        check.teacherNotes = [];
        check.resetYear = true;
        check.clearPerformance = true;
        check._performanceClearedAt = clearedAt;
        check._performanceEpoch = next._performanceEpoch;
        check._blockSubRebuildUntil = next._blockSubRebuildUntil;
        check.updatedAtMs = Date.now();
        saveAppData(id, check);
      }

      let subTableDeleted = 0;
      let attTableDeleted = 0;
      try {
        const r1 = db.prepare('DELETE FROM submissions WHERE school_id = ?').bind(id).run();
        subTableDeleted = (r1 && r1.meta && r1.meta.changes) || 0;
      } catch (e) {
        console.warn('reset-year submissions', e.message);
      }
      try {
        const r2 = db.prepare('DELETE FROM attendance_records WHERE school_id = ?').bind(id).run();
        attTableDeleted = (r2 && r2.meta && r2.meta.changes) || 0;
      } catch (e) {
        console.warn('reset-year attendance_records', e.message);
      }

      // تأیید نهایی
      const final = loadAppData(id);
      const finalAtt = Array.isArray(final.attendance) ? final.attendance.length : -1;
      const finalSub = Array.isArray(final.submissions) ? final.submissions.length : -1;

      return {
        ok: finalAtt === 0 && finalSub === 0,
        guard: 'node-reset-year-endpoint',
        beforeAttendance: beforeAtt,
        beforeSubmissions: beforeSub,
        attendance: finalAtt,
        submissions: finalSub,
        exams: 0,
        messages: 0,
        subTableDeleted,
        attTableDeleted,
        _performanceClearedAt: clearedAt,
        _performanceEpoch: next._performanceEpoch,
        classes: (final.classes || []).length,
        students: (final.students || []).length,
        staff: (final.staff || []).length,
        assignments: (final.assignments || []).length
      };
    })();

    return json(res, result);
  } catch (e) {
    console.error('reset-year', e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— appData PUT/POST ——
app.put('/api/schools/:id/appData', handleAppDataWrite);
app.post('/api/schools/:id/appData', handleAppDataWrite);

// مسیر مخصوص معلم (کلاینت به /appData/teacher می‌زند)
app.put('/api/schools/:id/appData/teacher', handleTeacherAppDataWrite);
app.post('/api/schools/:id/appData/teacher', handleTeacherAppDataWrite);

async function handleTeacherAppDataWrite(req, res) {
  try {
    const id = req.params.id;
    const body = req.body || {};
    // تراکنش تا دو درخواست هم‌زمان (مثلاً دو موجه) همدیگر را overwrite نکنند
    const result = sqlite.transaction(() => {
      const prev = loadAppData(id);
      let next = Object.assign({}, prev);
      if (Array.isArray(body.attendance)) {
        next.attendance = mergeAttendanceSafe(prev, body.attendance, body);
      }
      if (Array.isArray(body.submissions)) {
        next.submissions = mergeListSafe(prev, 'submissions', body.submissions, body);
      }
      if (Array.isArray(body.exams)) {
        next.exams = mergeListSafe(prev, 'exams', body.exams, body);
      }
      if (Array.isArray(body.messages)) {
        next.messages = mergeListSafe(prev, 'messages', body.messages, body);
      }
      if (Array.isArray(body.teacherNotes)) {
        next.teacherNotes = mergeListSafe(prev, 'teacherNotes', body.teacherNotes, body);
      }
      if (Array.isArray(body.sampleQuestions)) {
        next.sampleQuestions = mergeById(prev.sampleQuestions || [], body.sampleQuestions);
      }
      if (Array.isArray(body.staff) && body.staff.length) {
        next.staff = mergeById(prev.staff || [], body.staff);
      }
      if (body.staffSelfUpdate && body.staffSelfUpdate.id) {
        const sid = String(body.staffSelfUpdate.id);
        const staffList = Array.isArray(next.staff) ? next.staff.slice() : [];
        for (let i = 0; i < staffList.length; i++) {
          if (staffList[i] && String(staffList[i].id) === sid) {
            const upd = Object.assign({}, staffList[i]);
            if (body.staffSelfUpdate.photo !== undefined) upd.photo = body.staffSelfUpdate.photo || '';
            if (body.staffSelfUpdate.pass != null && String(body.staffSelfUpdate.pass).length >= 4) {
              upd.pass = String(body.staffSelfUpdate.pass);
              upd.password = upd.pass;
            }
            staffList[i] = upd;
            break;
          }
        }
        next.staff = staffList;
      }
      next = applySoftDeletes(next, body);
      next.updatedAtMs = Date.now();
      next._guard = 'node-teacher';
      saveAppData(id, mergeAuxiliary(prev, body, next), req);
      return { ok: true, guard: 'node-teacher' };
    })();
    return json(res, result);
  } catch (e) {
    console.error('teacher appData write', e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

async function handleAppDataWrite(req, res) {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);

    // مسیر soft (حضور و ...) — با compat مجاز؛ ساختار کلاس‌ها دست نمی‌خورد
    // تراکنش: دو موجه هم‌زمان همدیگر را overwrite نکنند
    if (body._softOnly === true || (req.viewer.role === 'teacher' && !body._partialDelta)) {
      const result = sqlite.transaction(() => {
        const prev = loadAppData(id);
        let next = Object.assign({}, prev);

        if (body.classMsgTemplates && typeof body.classMsgTemplates === 'object') {
          next.classMsgTemplates = Object.assign({}, prev.classMsgTemplates || {}, body.classMsgTemplates);
        }


        if (Array.isArray(body.classMessages)) {
          next.classMessages = mergeById(prev.classMessages || [], body.classMessages);
        }
        if (Array.isArray(body.deletedClassMessageIds) && body.deletedClassMessageIds.length) {
          const del = {};
          (prev.deletedClassMessageIds || []).forEach((x) => { if (x != null) del[String(x)] = true; });
          body.deletedClassMessageIds.forEach((x) => { if (x != null) del[String(x)] = true; });
          next.deletedClassMessageIds = Object.keys(del);
          next.classMessages = (next.classMessages || prev.classMessages || []).filter((m) => m && m.id != null && !del[String(m.id)]);
        }
        if (Array.isArray(body.staff) && body.staff.length && (auth.role === 'manager' || auth.role === 'mother')) {
          next.staff = mergeById(prev.staff || [], body.staff);
          if (body._forceStaffPass || body._staffOnly) {
            const list = Array.isArray(next.staff) ? next.staff.slice() : [];
            body.staff.forEach((inc) => {
              if (!inc || !inc.id) return;
              const np = String(inc.pass || inc.password || '').trim();
              if (np.length < 4) return;
              for (let i = 0; i < list.length; i++) {
                if (list[i] && String(list[i].id) === String(inc.id)) {
                  list[i] = Object.assign({}, list[i], { pass: np, password: np });
                  break;
                }
              }
            });
            next.staff = list;
          }
        }

        if (body._reviewOne === true) {
          if (Array.isArray(body.submissions) && body.submissions.length) {
            next.submissions = mergeListSafe(prev, 'submissions', body.submissions, body);
          }
          if (Array.isArray(body.attendance) && body.attendance.length) {
            next.attendance = mergeAttendanceSafe(prev, body.attendance, body);
          }
          next.updatedAtMs = Date.now();
          saveAppData(id, mergeAuxiliary(prev, body, next), req);
          return { ok: true, guard: 'node-review-one' };
        }
        // فقط تنظیمات (پیامک/قوانین) — سبک، برای هر دو شیفت
        if (body._settingsOnly === true) {
          if (body.smsConfig != null && typeof body.smsConfig === 'object') {
            next.smsConfig = Object.assign({}, prev.smsConfig || {}, body.smsConfig);
          }
          if (Array.isArray(body.smsTemplates)) next.smsTemplates = body.smsTemplates;
          if (body.rules != null && typeof body.rules === 'object') {
            next.rules = Object.assign({}, prev.rules || {}, body.rules);
          }
          next.updatedAtMs = Date.now();
          saveAppData(id, mergeAuxiliary(prev, body, next), req);
          return { ok: true, guard: 'node-settings-only' };
        }
        const softReset = body.resetYear === true || body.clearPerformance === true;
        if (softReset) {
          // بازنشانی: خالی واقعی — نه merge
          next.attendance = Array.isArray(body.attendance) ? body.attendance : [];
          next.submissions = Array.isArray(body.submissions) ? body.submissions : [];
          next.exams = Array.isArray(body.exams) ? body.exams : [];
          next.messages = Array.isArray(body.messages) ? body.messages : [];
          next.teacherNotes = Array.isArray(body.teacherNotes) ? body.teacherNotes : [];
          next.absentSmsSent = (body.absentSmsSent && typeof body.absentSmsSent === 'object') ? body.absentSmsSent : {};
          next.deletedAttendanceIds = Array.isArray(body.deletedAttendanceIds) ? body.deletedAttendanceIds : [];
          next.deletedSubmissionIds = Array.isArray(body.deletedSubmissionIds) ? body.deletedSubmissionIds : [];
          next.deletedAttendanceKeys = Array.isArray(body.deletedAttendanceKeys) ? body.deletedAttendanceKeys : [];
          next.resetYear = false;
          next.clearPerformance = false;
          next._performanceClearedAt = Date.now();
          next._performanceEpoch = (Number(prev._performanceEpoch) || 0) + 1;
        } else if (Array.isArray(body.attendance)) {
          next.attendance = mergeAttendanceSafe(prev, body.attendance, body);
        }
        if (!softReset && Array.isArray(body.submissions)) {
          next.submissions = mergeListSafe(prev, 'submissions', body.submissions, body);
        }
        if (!softReset && Array.isArray(body.teacherNotes)) {
          next.teacherNotes = mergeListSafe(prev, 'teacherNotes', body.teacherNotes, body);
        }
        if (!softReset && Array.isArray(body.exams)) {
          next.exams = mergeListSafe(prev, 'exams', body.exams, body);
        }
        if (!softReset && Array.isArray(body.messages)) {
          next.messages = mergeListSafe(prev, 'messages', body.messages, body);
        }
        if (Array.isArray(body.sampleQuestions)) {
          next.sampleQuestions = mergeById(prev.sampleQuestions || [], body.sampleQuestions);
        }
        if (Array.isArray(body.students) && body.students.length) {
          next.students = mergeById(prev.students || [], body.students);
        }
        if (Array.isArray(body.staff) && body.staff.length) {
          next.staff = mergeById(prev.staff || [], body.staff);
        }
        if (body.staffSelfUpdate && body.staffSelfUpdate.id) {
          const sid = String(body.staffSelfUpdate.id);
          const staffList = Array.isArray(next.staff) ? next.staff.slice() : [];
          for (let i = 0; i < staffList.length; i++) {
            if (staffList[i] && String(staffList[i].id) === sid) {
              const upd = Object.assign({}, staffList[i]);
              if (body.staffSelfUpdate.photo !== undefined) upd.photo = body.staffSelfUpdate.photo || '';
              if (body.staffSelfUpdate.pass != null && String(body.staffSelfUpdate.pass).length >= 4) {
                upd.pass = String(body.staffSelfUpdate.pass);
              upd.password = upd.pass;
              }
              staffList[i] = upd;
              break;
            }
          }
          next.staff = staffList;
        }
        next = applySoftDeletes(next, body);
        // بعد از بازنشانی: هر حضور قدیمی را دوباره رد کن
        if (!softReset && Array.isArray(next.attendance) && Number(next._performanceClearedAt) > 0) {
          const clearedAt = Number(next._performanceClearedAt);
          next.attendance = next.attendance.filter((x) => {
            if (!x) return false;
            const t = Number(x.createdAtMs) || Number(x.createdAt) || 0;
            return t > clearedAt;
          });
        }
        if (body.managerUser) next.managerUser = String(body.managerUser);
        if (body.managerPass != null && String(body.managerPass).length >= 4) {
          next.managerPass = String(body.managerPass);
        }
        if (body.managerPhoto !== undefined) next.managerPhoto = body.managerPhoto;
        next.updatedAtMs = Date.now();
        next._guard = 'node-soft';
        saveAppData(id, mergeAuxiliary(prev, body, next), req);
        return {
          ok: true,
          guard: 'node-soft',
          students: (next.students || []).length,
          staff: (next.staff || []).length,
          attendance: (next.attendance || []).length
        };
      })();
      return json(res, result);
    }

    // مسیر partial — تراکنش برای جلوگیری از race
    if (body._partialDelta === true) {
      const result = sqlite.transaction(() => {
        const prev = loadAppData(id);
        let next = Object.assign({}, prev);
        if (Array.isArray(body.classes) || body.deletedClassIds) {
          next.classes = mergeById(prev.classes, body.classes);
          if (Array.isArray(body.deletedClassIds) && body.deletedClassIds.length) {
            next.classes = filterOutByIds(next.classes, body.deletedClassIds);
          }
        }
        if (Array.isArray(body.students) || body.deletedStudentIds) {
          next.students = mergeById(prev.students, body.students);
          if (Array.isArray(body.deletedStudentIds) && body.deletedStudentIds.length) {
            next.students = filterOutByIds(next.students, body.deletedStudentIds);
          }
        }
        if (Array.isArray(body.staff) || body.deletedStaffIds) {
          next.staff = mergeById(prev.staff, body.staff);
          if (Array.isArray(body.deletedStaffIds) && body.deletedStaffIds.length) {
            next.staff = filterOutByIds(next.staff, body.deletedStaffIds);
          }
        }
        if (Array.isArray(body.assignments) || body.deletedAssignmentIds) {
          next.assignments = mergeById(prev.assignments, body.assignments);
          if (Array.isArray(body.deletedAssignmentIds) && body.deletedAssignmentIds.length) {
            next.assignments = filterOutByIds(next.assignments, body.deletedAssignmentIds);
          }
        }
        if (Array.isArray(body.attendance) || body.deletedAttendanceIds) {
          next.attendance = mergeAttendanceSafe(prev, body.attendance || [], body);
        }
        if (Array.isArray(body.submissions) || body.deletedSubmissionIds) {
          next.submissions = mergeListSafe(prev, 'submissions', body.submissions || [], body);
        }
        next = applySoftDeletes(next, body);
        if (body.managerUser !== undefined) next.managerUser = String(body.managerUser || '');
        if (body.managerPass != null && String(body.managerPass).length >= 4) next.managerPass = String(body.managerPass);
        if (body.smsConfig !== undefined) next.smsConfig = body.smsConfig;
        if (body.theme !== undefined) next.theme = body.theme;
        if (body.shifts !== undefined) next.shifts = body.shifts;
        next.updatedAtMs = Date.now();
        next._guard = 'node-partial';
        saveAppData(id, mergeAuxiliary(prev, body, next), req);
        return {
          ok: true,
          guard: 'node-partial',
          classes: (next.classes || []).length,
          students: (next.students || []).length,
          staff: (next.staff || []).length
        };
      })();
      return json(res, result);
    }

    // نوشتن کامل / ساختار
    if (!auth.ok) {
      return json(res, { ok: false, error: auth.error || 'auth_required', guard: 'node-auth' }, 401);
    }

    const prev = loadAppData(id);

    // بازیابی کامل بکاپ (صفر تا صد)
    // فقط مدیر/مادر می‌توانند بازیابی کامل ساختار کنند — نه هر _compatNoAuth
    const isFullRestore =
      body.confirmStructureWrite === 'NIKAN-STRUCT-OK' &&
      (body.replaceStructure === true || body.structureWriteToken === true) &&
      (auth.role === 'mother' || auth.role === 'manager');

    let payload;
    if (isFullRestore) {
      // جایگزینی کامل از body — همه فیلدهای عملیاتی
      payload = Object.assign({}, prev, body, {
        updatedAtMs: Date.now(),
        _guard: 'node-full-restore'
      });
      // فقط فیلدهای کنترل را از payload نهایی پاک کن
      delete payload.auth;
      delete payload._compatNoAuth;
      delete payload._motherPanel;
      delete payload.managerAuthority;
      delete payload.deputyAuthority;
      delete payload.replaceStructure;
      delete payload.replaceAssignments;
      delete payload.structureWriteToken;
      delete payload.confirmStructureWrite;
      delete payload.clearStructure;
      delete payload._partialDelta;
      delete payload._softOnly;
      // آرایه‌ها را مستقیم از بکاپ بگیر (نه merge)
      if (Array.isArray(body.classes)) payload.classes = body.classes;
      if (Array.isArray(body.students)) payload.students = body.students;
      if (Array.isArray(body.staff)) payload.staff = body.staff;
      if (Array.isArray(body.assignments)) payload.assignments = body.assignments;
      // حضور/عملکرد فقط وقتی بکاپ کامل یا بازنشانی است عوض شود
      // وگرنه ذخیره ساختار (کلاس/معلم) حضور بازنشانی‌شده را دوباره پر می‌کند
      const allowPerfReplace =
        body._fullRestore === true ||
        body.resetYear === true ||
        body.clearPerformance === true ||
        body._bypassPerfFilter === true;
      if (allowPerfReplace) {
        if (Array.isArray(body.attendance)) payload.attendance = body.attendance;
        if (Array.isArray(body.submissions)) payload.submissions = body.submissions;
        if (Array.isArray(body.exams)) payload.exams = body.exams;
        if (Array.isArray(body.messages)) payload.messages = body.messages;
      } else {
        payload.attendance = prev.attendance || [];
        payload.submissions = prev.submissions || [];
        payload.exams = prev.exams || [];
        payload.messages = prev.messages || [];
        if (prev._performanceClearedAt) payload._performanceClearedAt = prev._performanceClearedAt;
      }
      if (Array.isArray(body.colleagues)) payload.colleagues = body.colleagues;
      if (Array.isArray(body.teacherNotes)) payload.teacherNotes = body.teacherNotes;
      if (Array.isArray(body.sampleQuestions)) payload.sampleQuestions = body.sampleQuestions;
      if (Array.isArray(body.disciplinePhotos)) payload.disciplinePhotos = body.disciplinePhotos;
      if (Array.isArray(body.disciplineTypes)) payload.disciplineTypes = body.disciplineTypes;
      if (Array.isArray(body.smsTemplates)) payload.smsTemplates = body.smsTemplates;
      if (body.smsConfig != null) payload.smsConfig = body.smsConfig;
      if (body.theme != null) payload.theme = body.theme;
      if (body.shifts != null) payload.shifts = body.shifts;
      if (body.managerUser != null) payload.managerUser = body.managerUser;
      if (body.managerPass != null) payload.managerPass = body.managerPass;
      if (body.managerPhoto != null) payload.managerPhoto = body.managerPhoto;
      if (body.absentSmsSent != null) payload.absentSmsSent = body.absentSmsSent;
      if (Array.isArray(body.deletedAttendanceIds)) payload.deletedAttendanceIds = body.deletedAttendanceIds;
      if (Array.isArray(body.deletedSubmissionIds)) payload.deletedSubmissionIds = body.deletedSubmissionIds;
      // بازنشانی عملکرد داخل full path هم اعمال شود
      if (body.resetYear === true || body.clearPerformance === true) {
        payload.attendance = Array.isArray(body.attendance) ? body.attendance : [];
        payload.submissions = Array.isArray(body.submissions) ? body.submissions : [];
        payload.exams = Array.isArray(body.exams) ? body.exams : [];
        payload.messages = Array.isArray(body.messages) ? body.messages : [];
        payload.resetYear = true;
        payload.clearPerformance = true;
        payload._performanceClearedAt = Date.now();
      } else if (body._fullRestore === true || body._bypassPerfFilter === true) {
        // فقط بکاپ کامل عمدی قفل را برمی‌دارد
        payload._performanceClearedAt = 0;
        payload.resetYear = false;
        payload.clearPerformance = false;
      } else if (prev._performanceClearedAt) {
        // ذخیره ساختار نباید قفل بازنشانی را بشکند
        payload._performanceClearedAt = prev._performanceClearedAt;
        payload.resetYear = false;
        payload.clearPerformance = false;
      }
      // محافظت ساختار: خالی/کوچک‌تر شدن غیرعمدی را رد کن (باگ چندکاربره قدیمی)
      const isMgrWrite = body.managerAuthority === true || body._fullRestore === true
        || body.clearStructure === true || auth.role === 'manager' || auth.role === 'mother';
      if (body.clearStructure !== true) {
        if (!(payload.classes || []).length && (prev.classes || []).length && body.keepClasses !== false) {
          payload.classes = prev.classes;
        }
        if (!(payload.students || []).length && (prev.students || []).length && body.keepStudents !== false) {
          payload.students = prev.students;
        }
        if (!(payload.staff || []).length && (prev.staff || []).length && body.keepStaff !== false) {
          payload.staff = prev.staff;
        }
        const clearAsg = body.replaceAssignments === true || body.clearAssignments === true
          || body.resetYear === true || body.keepAssignments === false;
        if (!(payload.assignments || []).length && (prev.assignments || []).length && !clearAsg) {
          payload.assignments = prev.assignments;
        }
        // اگر کسی (غیر مدیر) لیست کلاس/دانش‌آموز کوتاه‌تر فرستاد، prev را نگه دار
        if (!isMgrWrite) {
          const pc = (prev.classes || []).length;
          const ps = (prev.students || []).length;
          const pa = (prev.assignments || []).length;
          if (pc > 0 && (payload.classes || []).length > 0 && (payload.classes || []).length < pc * 0.5) {
            payload.classes = prev.classes;
          }
          if (ps > 0 && (payload.students || []).length > 0 && (payload.students || []).length < ps * 0.5) {
            payload.students = prev.students;
          }
          if (pa > 0 && (payload.assignments || []).length > 0 && (payload.assignments || []).length < pa * 0.5
              && !body.replaceAssignments) {
            payload.assignments = prev.assignments;
          }
        }
      }
    } else {
      // بازنشانی سال / پاک‌سازی عملکرد: آرایه خالی باید واقعاً جایگزین شود (نه merge)
      const isPerfReset = body.resetYear === true || body.clearPerformance === true;
      payload = Object.assign({}, prev, {
        attendance: isPerfReset
          ? (Array.isArray(body.attendance) ? body.attendance : [])
          : (Array.isArray(body.attendance) ? mergeAttendanceSafe(prev, body.attendance, body) : (prev.attendance || [])),
        submissions: isPerfReset
          ? (Array.isArray(body.submissions) ? body.submissions : [])
          : (Array.isArray(body.submissions) ? mergeListSafe(prev, 'submissions', body.submissions, body) : (prev.submissions || [])),
        exams: isPerfReset
          ? (Array.isArray(body.exams) ? body.exams : [])
          : (Array.isArray(body.exams) ? mergeListSafe(prev, 'exams', body.exams, body) : (prev.exams || [])),
        messages: isPerfReset
          ? (Array.isArray(body.messages) ? body.messages : [])
          : (Array.isArray(body.messages) ? mergeListSafe(prev, 'messages', body.messages, body) : (prev.messages || [])),
        updatedAtMs: Date.now(),
        _guard: isPerfReset ? 'node-reset-year' : 'node-appdata'
      });
      if (isPerfReset) {
        payload.resetYear = true;
        payload.clearPerformance = true;
        payload._performanceClearedAt = Date.now();
        payload._performanceEpoch = (Number(prev._performanceEpoch) || 0) + 1;
        payload.teacherNotes = [];
        payload.absentSmsSent = (body.absentSmsSent && typeof body.absentSmsSent === 'object') ? body.absentSmsSent : {};
        if (Array.isArray(body.deletedAttendanceIds)) payload.deletedAttendanceIds = body.deletedAttendanceIds;
        else payload.deletedAttendanceIds = [];
        if (Array.isArray(body.deletedSubmissionIds)) payload.deletedSubmissionIds = body.deletedSubmissionIds;
        else payload.deletedSubmissionIds = [];
        if (Array.isArray(body.deletedAttendanceKeys)) payload.deletedAttendanceKeys = body.deletedAttendanceKeys;
        else payload.deletedAttendanceKeys = [];
      } else {
        // فلگ ریست را پاک کن تا همیشه کلاینت‌ها را در حالت ریست نگه ندارد
        payload.resetYear = false;
        payload.clearPerformance = false;
      }

      const wantStruct =
        (auth.role === 'mother' || auth.role === 'manager') &&
        (body.replaceStructure === true || body.structureWriteToken === true || body.confirmStructureWrite === 'NIKAN-STRUCT-OK');

      if (wantStruct || body.replaceStructure) {
        if (Array.isArray(body.classes)) payload.classes = body.clearStructure ? body.classes : mergeById(prev.classes, body.classes);
        if (Array.isArray(body.students)) payload.students = body.clearStructure ? body.students : mergeById(prev.students, body.students);
        if (Array.isArray(body.staff)) payload.staff = body.clearStructure ? body.staff : mergeById(prev.staff, body.staff);
        if (Array.isArray(body.assignments)) payload.assignments = body.clearStructure ? body.assignments : mergeById(prev.assignments, body.assignments);
      } else {
        // حفظ ساختار قبلی
        payload.classes = prev.classes || [];
        payload.students = prev.students || [];
        payload.staff = prev.staff || [];
        payload.assignments = prev.assignments || [];
      }

      if (body.smsConfig) payload.smsConfig = Object.assign({}, prev.smsConfig || {}, body.smsConfig);
      if (body.managerUser != null) payload.managerUser = body.managerUser;
      if (body.managerPass != null && String(body.managerPass).length > 0) payload.managerPass = body.managerPass;
      if (body.managerPhoto != null) payload.managerPhoto = body.managerPhoto;
      if (body.shifts != null) payload.shifts = body.shifts;
      if (body.theme != null) payload.theme = body.theme;
      if (Array.isArray(body.disciplineTypes)) payload.disciplineTypes = body.disciplineTypes;
      if (Array.isArray(body.smsTemplates)) payload.smsTemplates = body.smsTemplates;

      // هرگز ساختار را صفر نکن مگر clearStructure
      if (body.clearStructure !== true) {
        if ((prev.classes || []).length && !(payload.classes || []).length) payload.classes = prev.classes;
        if ((prev.students || []).length && !(payload.students || []).length) payload.students = prev.students;
        if ((prev.staff || []).length && !(payload.staff || []).length) payload.staff = prev.staff;
        if ((prev.assignments || []).length && !(payload.assignments || []).length) payload.assignments = prev.assignments;
      }

      // اعمال باطل/حذف حضور و ارسال (ساختار دست نخورده می‌ماند)
      payload = applySoftDeletes(payload, body);
    }

    if (!isFullRestore) payload = mergeAuxiliary(prev, body, payload);
    saveAppData(id, payload, req);
    return json(res, {
      ok: true,
      guard: payload._guard,
      classes: (payload.classes || []).length,
      students: (payload.students || []).length,
      staff: (payload.staff || []).length,
      assignments: (payload.assignments || []).length
    });
  } catch (e) {
    console.error('appData write', e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

// —— structure explicit ——
app.put('/api/schools/:id/appData/structure', handleStructure);
app.post('/api/schools/:id/appData/structure', handleStructure);

async function handleStructure(req, res) {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);
    if (!auth.ok) {
      return json(res, { ok: false, error: 'structure_forbidden' }, 403);
    }
    const prev = loadAppData(id);
    // از prev شروع کن تا colleagues / sms / theme و بقیه پاک نشوند
    let nextClasses = Array.isArray(body.classes) ? body.classes : (prev.classes || []);
    let nextStudents = Array.isArray(body.students) ? body.students : (prev.students || []);
    let nextStaff = Array.isArray(body.staff) ? body.staff : (prev.staff || []);
    let nextAssign = Array.isArray(body.assignments) ? body.assignments : (prev.assignments || []);
    // جلوگیری از پاک شدن ساختار وقتی درخواست ناقص است (چند کاربر هم‌زمان)
    if (body.clearStructure !== true) {
      if ((prev.classes || []).length > 0 && nextClasses.length === 0) nextClasses = prev.classes;
      if ((prev.students || []).length > 0 && nextStudents.length === 0) nextStudents = prev.students;
      if ((prev.staff || []).length > 0 && nextStaff.length === 0) nextStaff = prev.staff;
      if ((prev.assignments || []).length > 0 && nextAssign.length === 0 && !body.replaceAssignments) nextAssign = prev.assignments;
      if ((prev.classes || []).length > 5 && nextClasses.length > 0 && nextClasses.length < (prev.classes || []).length * 0.5
          && body.managerAuthority !== true) {
        nextClasses = prev.classes;
        nextStudents = prev.students;
      }
    }
    const payload = Object.assign({}, prev, {
      classes: nextClasses,
      students: nextStudents,
      staff: nextStaff,
      assignments: nextAssign,
      updatedAtMs: Date.now(),
      _guard: 'node-structure'
    });
    // دفترچه همکاران + تنظیمات پیامک
    if (Array.isArray(body.colleagues)) payload.colleagues = body.colleagues;
    else if (!Array.isArray(payload.colleagues)) payload.colleagues = prev.colleagues || [];
    if (body.smsConfig != null) payload.smsConfig = body.smsConfig;
    if (Array.isArray(body.smsTemplates)) payload.smsTemplates = body.smsTemplates;
    if (body.theme != null) payload.theme = body.theme;
    if (body.rules != null) payload.rules = body.rules;
    if (body.managerUser != null) payload.managerUser = body.managerUser;
    if (body.managerPass != null && String(body.managerPass).length) payload.managerPass = body.managerPass;
    if (body.shifts != null) payload.shifts = body.shifts;
    if (Array.isArray(body.disciplineTypes)) payload.disciplineTypes = body.disciplineTypes;
    if (body.clearStructure === true) {
      payload.classes = Array.isArray(body.classes) ? body.classes : [];
      payload.students = Array.isArray(body.students) ? body.students : [];
      payload.staff = Array.isArray(body.staff) ? body.staff : [];
      payload.assignments = Array.isArray(body.assignments) ? body.assignments : [];
      if (Array.isArray(body.colleagues)) payload.colleagues = body.colleagues;
    }
    // قفل بازنشانی را نشکن
    if (prev._performanceClearedAt) {
      payload._performanceClearedAt = prev._performanceClearedAt;
      payload._performanceEpoch = prev._performanceEpoch;
      payload._blockSubRebuildUntil = prev._blockSubRebuildUntil;
    }
    delete payload._hadRow;
    const filtered = mergeAuxiliary(prev, body, payload);
    saveAppData(id, filtered);
    return json(res, {
      ok: true,
      guard: 'node-structure',
      classes: (payload.classes || []).length,
      students: (payload.students || []).length,
      staff: (payload.staff || []).length,
      assignments: (payload.assignments || []).length,
      colleagues: (payload.colleagues || []).length
    });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

// —— Submissions ——
app.get('/api/schools/:id/submissions', (req, res) => {
  try {
    const id = req.params.id;
    const full = loadAppData(id);
    const rows = db.prepare('SELECT data FROM submissions WHERE school_id = ? ORDER BY created_at DESC').bind(id).all().results;
    const queued = rows.map(r => JSON.parse(r.data));
    let submissions = mergeById(queued, full.submissions || []);
    submissions = filterPostResetPerformance(full, submissions, {});
    submissions = filterOutByIds(submissions, full.deletedSubmissionIds || []);
    if (['teacher', 'deputy'].includes(req.viewer.role)) {
      const scoped = scopeAppDataForViewer(full, viewerQuery(req));
      const classes = new Set((scoped.classes || []).map(c => String(c.id)));
      submissions = submissions.filter(s => classes.has(String(s.classId)) &&
        (req.viewer.role !== 'teacher' || String(s.teacherId) === req.viewer.staffId));
    }
    return json(res, { ok: true, submissions });
  } catch (e) {
    return json(res, { ok: false, error: 'server_error' }, 500);
  }
});

app.post('/api/schools/:id/submissions', (req, res) => {
  try {
    const schoolId = req.params.id;
    const body = req.body || {};
    if (!loadSchoolRow(schoolId)) return json(res, { ok: false, error: 'school_not_found' }, 404);
    const result = sqlite.transaction(() => {
      const full = loadAppData(schoolId);
      const id = String(body.id || crypto.randomUUID());
      if ((full.deletedSubmissionIds || []).map(String).includes(id)) return { error: 'submission_deleted', statusCode: 410 };
      if (!filterPostResetPerformance(full, [body], {}).length) return { error: 'stale_performance', statusCode: 409 };
      const row = db.prepare('SELECT data FROM submissions WHERE school_id = ? AND id = ?').bind(schoolId, id).first();
      const previous = (full.submissions || []).find(s => String(s.id) === id) || (row && JSON.parse(row.data));
      let payload = Object.assign({}, body, { id, createdAtMs: previous ? previous.createdAtMs : (Number(body.createdAtMs) || Number(body.createdAt) || Date.now()), syncedAt: Date.now() });
      for (const key of ['auth', 'pass', '_compatNoAuth', '_motherPanel', 'managerAuthority']) delete payload[key];
      if (previous) payload = mergeById([previous], [payload])[0];
      if (payload.voided || payload.cancelled || payload.status === 'voided') return { error: 'submission_deleted', statusCode: 410 };
      // Preserve review state across retries that use a different submission id.
      const duplicate = (full.submissions || []).find(s => s.id !== id && body.assignId && body.date && body.teacherId &&
        String(s.assignId) === String(body.assignId) && s.date === body.date && String(s.teacherId) === String(body.teacherId));
      if (duplicate) {
        const merged = mergeById([Object.assign({}, duplicate, { id })], [payload]);
        payload = merged[0];
        const statuses = new Map((payload.rows || []).map(r => [String(r.studentId), r.status]));
        const removedAttendance = [];
        full.attendance = (full.attendance || []).filter(a => {
          if (String(a.submissionId) !== String(duplicate.id)) return true;
          if (String(a.teacherId || duplicate.teacherId) !== String(body.teacherId)) return true;
          const status = statuses.get(String(a.studentId));
          if (status === (a.type || 'absent')) { a.submissionId = id; return true; }
          removedAttendance.push(String(a.id)); return false;
        });
        full.deletedAttendanceIds = mergeDeletedIds(full.deletedAttendanceIds, removedAttendance);
        // Superseded snapshots must never overwrite the corrected slot later.
        full.deletedSubmissionIds = mergeDeletedIds(full.deletedSubmissionIds, [String(duplicate.id)]);
        full.submissions = (full.submissions || []).filter(s => s.id !== duplicate.id);
        db.prepare('DELETE FROM submissions WHERE school_id = ? AND id = ?').bind(schoolId, String(duplicate.id)).run();
      }
      db.prepare(`INSERT INTO submissions (id, school_id, assign_id, teacher_id, date, data, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(school_id, id) DO UPDATE SET assign_id=excluded.assign_id,
        teacher_id=excluded.teacher_id, date=excluded.date, data=excluded.data, created_at=excluded.created_at`)
        .bind(id, schoolId, body.assignId == null ? null : String(body.assignId), body.teacherId == null ? null : String(body.teacherId),
          body.date || null, JSON.stringify(payload), payload.createdAtMs).run();
      full.submissions = mergeById(full.submissions || [], [payload]);
      saveAppData(schoolId, full);
      return { ok: true, id, status: payload.status || 'pending' };
    })();
    return json(res, result, result.statusCode || 200);
  } catch (e) {
    console.error('submission write', e.message);
    return json(res, { ok: false, error: 'server_error' }, 500);
  }
});

app.delete('/api/schools/:id/submissions', (req, res) => {
  const id = req.params.id;
  const subId = String((req.body || {}).id || '');
  if (!subId) return json(res, { ok: false, error: 'id_required' }, 400);
  sqlite.transaction(() => {
    const data = loadAppData(id);
    const next = applySoftDeletes(data, { deletedSubmissionIds: [subId] });
    saveAppData(id, next);
  })();
  return json(res, { ok: true, deleted: subId, guard: 'node-sub-delete' });
});

// پاک‌سازی همه ارسال‌های حضور (بازنشانی سال)
app.post('/api/schools/:id/submissions/clear', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);
    if (!auth.ok) {
      return json(res, { ok: false, error: auth.error || 'auth_required' }, 401);
    }
    sqlite.transaction(() => {
      const data = loadAppData(id);
      data.deletedSubmissionIds = mergeDeletedIds(data.deletedSubmissionIds, (data.submissions || []).map(s => s.id));
      data.submissions = [];
      data.attendance = (data.attendance || []).filter(a => !a.submissionId);
      db.prepare('DELETE FROM submissions WHERE school_id = ?').bind(id).run();
      saveAppData(id, data);
    })();
    return json(res, { ok: true, guard: 'node-sub-clear' });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// Parent appearance is stored separately so saving school branding cannot overwrite it.
const parentBranding = require('./lib/parent-branding');
app.get('/api/parent-branding', (req, res) => {
  try {
    const row = sqlite.prepare('SELECT data,updated_at FROM app_data WHERE school_id=?').get('__nikan_parent_branding__');
    const data = row ? JSON.parse(row.data) : {};
    return json(res, { ok:true, branding:parentBranding.normalize(data), updatedAt:row?row.updated_at:0 });
  } catch { return json(res, {ok:false,error:'branding_unavailable'},503); }
});
app.put('/api/parent-branding', (req, res) => {
  if (!req.viewer || req.viewer.role!=='mother') return json(res,{ok:false,error:'forbidden'},403);
  const body=req.body||{};
  if (!body.branding || typeof body.branding!=='object' || Array.isArray(body.branding)) return json(res,{ok:false,error:'invalid_branding'},400);
  const data=parentBranding.normalize(body.branding), now=Date.now();
  sqlite.prepare('INSERT INTO app_data(school_id,data,updated_at) VALUES(?,?,?) ON CONFLICT(school_id) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at')
    .run('__nikan_parent_branding__',JSON.stringify(data),now);
  return json(res,{ok:true,branding:data,updatedAt:now});
});

// —— Branding ——
app.get('/api/branding', (req, res) => {
  try {
    const row = db.prepare('SELECT data, updated_at FROM app_data WHERE school_id = ?').bind('__nikan_branding__').first();
    let data = {};
    if (row && row.data) {
      try { data = JSON.parse(row.data) || {}; } catch (e) {}
    }
    return json(
      res,
      Object.assign(
        {
          ok: true,
          logo: '',
          title: '',
          subtitle: '',
          announce: '',
          ad: '',
          adLink: '',
          bg: '#070b14',
          accent: '#38bdf8',
          text: '#e8eef7',
          card: '#111a2e',
          font: 'Tahoma, sans-serif',
          titleSize: '1.65rem',
          bodySize: '14.5px',
          bgImage: '',
          bgOverlay: 55,
          enabled: true,
          updatedAt: row && row.updated_at ? row.updated_at : 0
        },
        data,
        { ok: true }
      )
    );
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 503);
  }
});

app.put('/api/branding', handleBranding);
app.post('/api/branding', handleBranding);

function handleBranding(req, res) {
  try {
    const body = req.body || {};
    const roleHdr = String((body.auth && body.auth.role) || req.headers['x-auth-role'] || '').toLowerCase();
    const isMother = (req.viewer && req.viewer.role === 'mother') || motherKeyOk(req) || roleHdr === 'mother';
    if (!isMother) return json(res, { ok: false, error: 'auth_required' }, 401);

    const payload = {
      logo: body.logo != null ? String(body.logo) : '',
      bgImage: body.bgImage != null ? String(body.bgImage) : '',
      enabled: body.enabled !== false,
      title: String(body.title || '').trim().slice(0, 80),
      subtitle: String(body.subtitle || '').trim().slice(0, 120),
      announce: String(body.announce || '').trim().slice(0, 300),
      ad: String(body.ad || '').trim().slice(0, 400),
      adLink: String(body.adLink || '').trim().slice(0, 300),
      bg: String(body.bg || '#070b14').slice(0, 20),
      accent: String(body.accent || '#38bdf8').slice(0, 20),
      text: String(body.text || '#e8eef7').slice(0, 20),
      card: String(body.card || '#111a2e').slice(0, 20),
      font: String(body.fontBody || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontTitle: String(body.fontTitle || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontSubtitle: String(body.fontSubtitle || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontBody: String(body.fontBody || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontAnnounce: String(body.fontAnnounce || body.font || 'Tahoma, sans-serif').slice(0, 120),
      titleSize: String(body.titleSize || '1.65rem').slice(0, 20),
      bodySize: String(body.bodySize || '14.5px').slice(0, 20),
      bgOverlay: Math.min(90, Math.max(0, Number.isFinite(Number(body.bgOverlay)) ? Number(body.bgOverlay) : 55)),
      updatedAtMs: Date.now()
    };
    db.prepare(
      `INSERT INTO app_data (school_id, data, updated_at) VALUES (?, ?, ?)
       ON CONFLICT(school_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`
    )
      .bind('__nikan_branding__', JSON.stringify(payload), Date.now())
      .run();
    return json(res, { ok: true, saved: true, updatedAt: payload.updatedAtMs });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

// —— SMS proxy (اختیاری) ——
app.post('/api/sms/send', async (req, res) => {
  try {
    const incoming = req.body || {};
    const stored = loadAppData(String(incoming.schoolId || '')).smsConfig || {};
    const school = loadSchoolRow(String(incoming.schoolId || '')) || {};
    const defaults = Object.assign({ username: school.smsApiUser, password: school.smsApiKey,
      apiUrl: school.smsApiUrl, sender: school.smsSender }, stored);
    const body = req.viewer.role === 'deputy' ? Object.assign({}, defaults, { phones: incoming.phones, text: incoming.text }) : Object.assign({}, defaults, incoming);
    const provider = String(body.provider || 'melipayamak').toLowerCase();
    const username = String(body.username || '').trim();
    const password = String(body.password || body.apiKey || '').trim();
    const sender = String(body.sender || '').trim();
    const text = String(body.text || '');
    const apiUrl = String(body.apiUrl || '').trim();
    if (apiUrl) {
      let destination;
      try { destination = new URL(apiUrl); } catch { return json(res, { ok: false, error: 'invalid_sms_url' }, 400); }
      const allowed = new Set(['https://rest.payamak-panel.com', 'https://api.kavenegar.com',
        ...(process.env.SMS_ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean)]);
      if (!['http:', 'https:'].includes(destination.protocol) || destination.username || destination.password || !allowed.has(destination.origin)) {
        return json(res, { ok: false, error: 'sms_origin_not_allowed' }, 400);
      }
    }
    let phones = Array.isArray(body.phones) ? body.phones : [];
    phones = phones
      .map((p) => String(p || '').replace(/\D/g, ''))
      .map((p) => (p.startsWith('98') && p.length > 10 ? '0' + p.slice(2) : p))
      .filter((p) => /^09\d{9}$/.test(p));
    phones = [...new Set(phones)];
    if (phones.length > 30) return json(res, { ok: false, error: 'sms_batch_too_large' }, 400);

    if (!text) return json(res, { ok: false, error: 'empty_text', sent: 0, total: 0, results: [] }, 400);
    if (!phones.length) return json(res, { ok: false, error: 'no_phones', sent: 0, total: 0, results: [] }, 400);
    if (!username && !password) {
      return json(res, {
        ok: false,
        error: 'sms_credentials_missing',
        sent: 0,
        total: phones.length,
        results: [],
        hint: 'نام کاربری و رمز پنل پیامک را در تنظیمات مدرسه ذخیره کنید'
      }, 400);
    }

    const results = [];
    let sent = 0;

    async function postJson(url, payload) {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(15000),
        redirect: 'error'
      });
      const raw = await r.text();
      let data = null;
      try { data = JSON.parse(raw); } catch (e) { data = { raw }; }
      return { status: r.status, data, raw };
    }

    // —— ملی‌پیامک (Melipayamak) ——
    async function sendMelipayamak() {
      const url = apiUrl || 'https://rest.payamak-panel.com/api/SendSMS/SendSMS';
      for (const to of phones) {
        try {
          const { status, data, raw } = await postJson(url, {
            username,
            password,
            to,
            from: sender || '',
            text,
            isFlash: false
          });
          // Value > 0 یعنی recId موفق؛ منفی یا رشته خطا
          let val = data && (data.Value != null ? data.Value : data.value);
          if (val == null && data && data.RetStatus != null) val = data.RetStatus;
          const num = Number(val);
          const ok = status >= 200 && status < 300 && ((typeof val === 'string' && /^\d{5,}$/.test(val)) || (Number.isFinite(num) && num > 10));
          if (ok) {
            sent += 1;
            results.push({ phone: to, ok: true, id: String(val) });
          } else {
            results.push({
              phone: to,
              ok: false,
              error: String(val != null ? val : (data && (data.StrRetStatus || data.message)) || raw || status)
            });
          }
        } catch (e) {
          results.push({ phone: to, ok: false, error: String(e.message || e) });
        }
      }
    }

    // —— کاوه‌نگار ——
    async function sendKavenegar() {
      const key = password || username;
      const base = apiUrl || ('https://api.kavenegar.com/v1/' + encodeURIComponent(key) + '/sms/send.json');
      for (const to of phones) {
        try {
          const u = new URL(base);
          u.searchParams.set('receptor', to);
          u.searchParams.set('message', text);
          if (sender) u.searchParams.set('sender', sender);
          const r = await fetch(u.toString(), { method: 'GET', signal: AbortSignal.timeout(15000), redirect: 'error' });
          const data = await r.json().catch(() => ({}));
          const ok = r.ok && data && data.return && Number(data.return.status) === 200;
          if (ok) {
            sent += 1;
            results.push({ phone: to, ok: true, id: data.entries && data.entries[0] && data.entries[0].messageid });
          } else {
            results.push({ phone: to, ok: false, error: (data.return && data.return.message) || r.status });
          }
        } catch (e) {
          results.push({ phone: to, ok: false, error: String(e.message || e) });
        }
      }
    }

    // —— عمومی: POST JSON به apiUrl ——
    async function sendGeneric() {
      if (!apiUrl) throw new Error('apiUrl لازم است');
      for (const to of phones) {
        try {
          const { status, data, raw } = await postJson(apiUrl, {
            username, password, apiKey: password, from: sender, sender, to, phone: to, text, message: text
          });
          const ok = status >= 200 && status < 300 && !(data && data.ok === false);
          if (ok) {
            sent += 1;
            results.push({ phone: to, ok: true });
          } else {
            results.push({ phone: to, ok: false, error: (data && (data.error || data.message)) || raw || status });
          }
        } catch (e) {
          results.push({ phone: to, ok: false, error: String(e.message || e) });
        }
      }
    }

    if (provider.includes('kavenegar') || provider === 'کاوه') {
      await sendKavenegar();
    } else if (provider.includes('meli') || provider.includes('payamak') || provider === 'melipayamak' || !apiUrl) {
      await sendMelipayamak();
    } else {
      await sendGeneric();
    }

    return json(res, {
      ok: sent > 0,
      sent,
      total: phones.length,
      results,
      error: sent === 0 ? (results[0] && results[0].error) || 'send_failed' : undefined
    });
  } catch (e) {
    console.error('sms/send', e);
    return json(res, { ok: false, error: String(e.message || e), sent: 0, total: 0, results: [] }, 500);
  }
});

// 404 API
app.use('/api', (req, res) => {
  json(res, { ok: false, error: 'route not found', path: req.path }, 404);
});

// خطا
app.use((err, req, res, next) => {
  console.error('unhandled', err.message);
  const status = err.status || 500;
  json(res, { ok: false, error: status === 400 ? 'invalid_json' : status === 413 ? 'payload_too_large' : 'server_error' }, status);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Nikan server on port', PORT);
  console.log('DB ready');
});
