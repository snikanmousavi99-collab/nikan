#!/usr/bin/env node
'use strict';
// Operator-only recovery to the requested initial password.
const crypto = require('crypto');
const { sqlite } = require('../db');
const { normalizePhone } = require('../parent-portal');
const phone = normalizePhone(process.argv[2]);
try {
 if (!phone) throw new Error('Usage: npm run parent:reset -- 09xxxxxxxxx');
 const exists = sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='parent_accounts'").get();
 if (!exists || !sqlite.prepare('SELECT phone FROM parent_accounts WHERE phone=?').get(phone)) throw new Error('Parent account not found; start the new server and complete first login.');
 const temporary = '123456', salt = crypto.randomBytes(16).toString('hex');
 const hash = crypto.scryptSync(temporary, salt, 64).toString('hex');
 sqlite.transaction(() => {
  sqlite.prepare('UPDATE parent_accounts SET salt=?,hash=?,must_change=1,version=version+1,updated_at=? WHERE phone=?')
   .run(salt, hash, Date.now(), phone);
  sqlite.prepare('DELETE FROM parent_sessions WHERE phone=?').run(phone);
  sqlite.prepare('DELETE FROM parent_login_limits WHERE key IN (?,?)').run('phone:'+phone,'password:'+phone);
 })();
 console.log('Temporary password (deliver privately to the verified guardian): ' + temporary);
 console.log('All prior sessions were revoked. A new personal password is required at next login.');
} catch (error) { console.error(error.message); process.exitCode=1; }
finally { sqlite.close(); }
