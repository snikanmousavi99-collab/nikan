/* Mother-only editor; server is the authority for persistence and permissions. */
(function(){
'use strict';
const schema=window.NikanParentBranding, form=document.getElementById('parent-branding-form');
if(!schema||!form)return;
const get=id=>document.getElementById(id), controls=get('parent-branding-controls'), status=get('pb-status'), preview=get('pb-preview');
let images={logo:'',backgroundImage:''}, generation=0, uploads=0, busy=false;
const identity=()=>state.motherUser+'\n'+(state.motherPass||'');
const valid=(token,user)=>token===generation&&user===identity()&&!!state.motherPass;
const fieldRoot=get('pb-fields');
function field(key,label,input){const box=document.createElement('div'),l=document.createElement('label');l.htmlFor='pb-'+key;l.textContent=label;input.id=l.htmlFor;box.append(l,input);fieldRoot.append(box);return input;}
for(const [key,[label,,max]]of Object.entries(schema.texts)){const el=document.createElement('textarea');el.rows=key==='heroTitle'?2:3;el.maxLength=max;field(key,label,el);}
for(const [key,[label]]of Object.entries(schema.colors)){const el=document.createElement('input');el.type='color';field(key,label,el);}
const font=field('font','فونت',document.createElement('select'));
for(const [value,label]of [['Vazirmatn','وزیرمتن'],['Tahoma','تاهوما'],['Arial','آریال']]){const option=document.createElement('option');option.value=value;option.textContent=label;font.append(option);}
for(const [key,label,min,max]of [['bodySize','اندازه متن',12,18],['titleSize','اندازه نام سامانه',16,28]]){const el=document.createElement('input');el.type='number';el.min=min;el.max=max;field(key,label,el);}
function collect(){const data={enabled:get('pb-enabled').checked,...images};for(const key of [...Object.keys(schema.texts),...Object.keys(schema.colors),'font'])data[key]=get('pb-'+key).value;for(const key of ['bodySize','titleSize'])data[key]=Number(get('pb-'+key).value);return schema.normalize(data);}
function render(){schema.apply(preview,collect(),false);}
function fill(data){const normalized=schema.normalize(data);get('pb-enabled').checked=normalized.enabled;images={logo:normalized.logo,backgroundImage:normalized.backgroundImage};for(const key of [...Object.keys(schema.texts),...Object.keys(schema.colors),'font','bodySize','titleSize'])get('pb-'+key).value=normalized[key];for(const key of ['logo','backgroundImage'])get('pb-'+key+'-file').value='';render();}
window.resetParentBrandingMother=function(){generation++;controls.disabled=true;fill(schema.defaults);status.textContent='';};
window.loadParentBrandingIntoMother=async function(){
 if(busy||uploads)return;
 const token=++generation,user=identity();controls.disabled=true;status.textContent='در حال دریافت تنظیمات ذخیره‌شده…';
 try{const response=await apiFetch('/api/parent-branding',{method:'GET',retries:1,timeoutMs:12000});if(!valid(token,user))return;if(!response||!response.ok||!response.branding)throw Error('پاسخ نامعتبر سرور');fill(response.branding);controls.disabled=false;status.textContent='تنظیمات از سرور خوانده شد. تغییرات پس از ذخیره اعمال می‌شوند.';}
 catch(error){if(valid(token,user))status.textContent='دریافت تنظیمات ناموفق بود: '+error.message+'؛ خواندن دوباره از سرور را بزنید.';}
};
form.addEventListener('input',render);
get('pb-reload').addEventListener('click',()=>window.loadParentBrandingIntoMother());
get('pb-defaults').addEventListener('click',()=>{if(uploads)return;fill(schema.defaults);status.textContent='مقادیر پیش‌فرض در فرم قرار گرفت؛ برای اعمال، ذخیره کنید.';});
for(const key of ['logo','backgroundImage']){
 get('pb-clear-'+key).addEventListener('click',()=>{images[key]='';get('pb-'+key+'-file').value='';render();});
 get('pb-'+key+'-file').addEventListener('change',async event=>{
  const file=event.target.files[0];if(!file)return;const token=generation,user=identity();uploads++;controls.disabled=true;get('pb-reload').disabled=true;
  try{
   if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>10*1024*1024)throw Error('تصویر PNG، JPEG یا WebP با حجم حداکثر ۱۰ مگابایت انتخاب کنید.');
   const bitmap=await createImageBitmap(file);
   try{
    const bound=key==='logo'?400:1400,scale=Math.min(1,bound/Math.max(bitmap.width,bitmap.height)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
    const value=canvas.toDataURL('image/webp',.8),checked=schema.normalize({[key]:value})[key];if(!checked)throw Error('حجم تصویر پس از فشرده‌سازی زیاد است؛ تصویر کوچک‌تری انتخاب کنید.');
    if(valid(token,user)){images[key]=checked;render();status.textContent='تصویر آماده شد؛ برای اعمال، ذخیره کنید.';}
   }finally{bitmap.close();}
  }catch(error){if(valid(token,user))status.textContent=error.message;}
  finally{uploads--;get('pb-reload').disabled=false;if(valid(token,user)&&!busy)controls.disabled=false;}
 });
}
form.addEventListener('submit',async event=>{
 event.preventDefault();if(busy||uploads||controls.disabled||!state.motherPass)return;
 const token=++generation,user=identity(),payload=collect();busy=true;controls.disabled=true;get('pb-reload').disabled=true;status.textContent='در حال ذخیره روی سرور…';
 try{const response=await apiFetch('/api/parent-branding',{method:'PUT',body:{branding:payload},retries:1,timeoutMs:20000});if(!valid(token,user))return;if(!response||!response.ok||!response.branding)throw Error('پاسخ نامعتبر سرور');fill(response.branding);status.textContent='ظاهر والدین روی سرور ذخیره شد ✓ والدین با تازه‌کردن صفحه تغییرات را می‌بینند.';}
 catch(error){if(valid(token,user))status.textContent='ذخیره تأیید نشد: '+error.message+'؛ اتصال را بررسی و دوباره تلاش کنید.';}
 finally{busy=false;get('pb-reload').disabled=false;if(valid(token,user))controls.disabled=false;}
});
fill(schema.defaults);
})();
