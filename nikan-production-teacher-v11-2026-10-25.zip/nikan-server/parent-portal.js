'use strict';
const express = require('express');
const crypto = require('crypto');
const { promisify } = require('util');
const scrypt = promisify(crypto.scrypt);
const { reportRules, normalizeDateToIso } = require('./lib/parent-performance');
const COOKIE = 'nikan_parent_session';
const SESSION_MS = 12 * 60 * 60 * 1000;
const MAX_FILE = 3 * 1024 * 1024;
const digits = value => String(value || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
function normalizePhone(value) {
  let n = digits(value).replace(/[\s()\-]/g, '');
  if (n.startsWith('+98')) n = '0' + n.slice(3);
  else if (n.startsWith('0098')) n = '0' + n.slice(4);
  else if (/^98\d{10}$/.test(n)) n = '0' + n.slice(2);
  else if (/^9\d{9}$/.test(n)) n = '0' + n;
  return /^09\d{9}$/.test(n) ? n : '';
}
function phones(student) {
  return [...(Array.isArray(student.phones) ? student.phones : []), student.phone, student.fatherPhone, student.motherPhone, student.parentPhone]
    .map(normalizePhone).filter(Boolean);
}
const hashToken = token => crypto.createHash('sha256').update(token).digest('hex');
const fail = (status, error) => Object.assign(new Error(error), { status });
function validDate(value) {
  const day = normalizeDateToIso(value);
  if (!day || !/^\d{4}-\d{2}-\d{2}$/.test(day)) return '';
  const date = new Date(day + 'T12:00:00Z');
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === day ? day : '';
}
function readFile(input) {
  if (!input || typeof input.data !== 'string' || typeof input.name !== 'string') throw fail(400, 'invalid_file');
  const m = input.data.match(/^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,([A-Za-z0-9+/]+={0,2})$/);
  if (!m || m[2].length > Math.ceil(MAX_FILE / 3) * 4) throw fail(400, 'invalid_file');
  const bytes = Buffer.from(m[2], 'base64');
  if (!bytes.length || bytes.length > MAX_FILE || bytes.toString('base64') !== m[2]) throw fail(400, 'invalid_file');
  const mime = m[1];
  const real = mime === 'image/jpeg' ? bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255
    : mime === 'image/png' ? bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'))
    : mime === 'image/webp' ? bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP'
    : bytes.toString('ascii', 0, 5) === '%PDF-';
  if (!real) throw fail(400, 'invalid_file');
  const extension = { 'application/pdf': '.pdf', 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }[mime];
  const basename = input.name.replace(/[\x00-\x1f\x7f\\/]/g, '_').replace(/\.[^.]*$/, '').slice(0, 140) || 'medical-document';
  return { bytes, mime, name: basename + extension };
}

function installParentPortal(app, deps) {
  const { sqlite, loadAppData, saveAppData, loadSchoolRow, schoolUnavailable, authenticateWrite,
    scopeAppDataForViewer, viewerQuery, applySoftDeletes, json } = deps;
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS parent_accounts (
      phone TEXT PRIMARY KEY, salt TEXT NOT NULL, hash TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 1,
      version INTEGER NOT NULL DEFAULT 1, updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS parent_sessions (
      token_hash TEXT PRIMARY KEY, phone TEXT NOT NULL REFERENCES parent_accounts(phone) ON DELETE CASCADE,
      version INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_parent_sessions_phone ON parent_sessions(phone);
    CREATE TABLE IF NOT EXISTS parent_login_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, until_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS parent_medical_requests (
      id TEXT PRIMARY KEY, school_id TEXT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      student_id TEXT NOT NULL, parent_phone TEXT NOT NULL, dates TEXT NOT NULL, note TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending', decision_note TEXT NOT NULL DEFAULT '',
      reviewer TEXT NOT NULL DEFAULT '', reviewed_at INTEGER, created_at INTEGER NOT NULL,
      file_name TEXT NOT NULL, file_mime TEXT NOT NULL, file_data BLOB NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_parent_requests_school ON parent_medical_requests(school_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_parent_requests_phone ON parent_medical_requests(parent_phone, created_at);
  `);
  const wrap = fn => (req, res, next) => Promise.resolve().then(() => fn(req, res)).catch(error => {
    if (error.status) return json(res, { ok: false, error: error.message }, error.status);
    next(error);
  });
  function sameOrigin(req) {
    const origin = req.headers.origin;
    if (req.headers['sec-fetch-site'] === 'cross-site') throw fail(403, 'origin_forbidden');
    if (origin) {
      let url; try { url = new URL(origin); } catch { throw fail(403, 'origin_forbidden'); }
      if (!['http:', 'https:'].includes(url.protocol) || url.host !== req.get('host')) throw fail(403, 'origin_forbidden');
    }
    if (req.method !== 'GET' && !req.is('application/json')) throw fail(415, 'json_required');
  }
  function rateLimit(key, max, minutes) {
    const now = Date.now();
    const result = sqlite.prepare(`INSERT INTO parent_login_limits(key,count,until_at) VALUES(?,1,?)
      ON CONFLICT(key) DO UPDATE SET count=CASE WHEN until_at<=? THEN 1 ELSE count+1 END,
      until_at=CASE WHEN until_at<=? THEN excluded.until_at ELSE until_at END RETURNING count,until_at`)
      .get(key, now + minutes * 60000, now, now);
    if (result.count > max) throw fail(429, 'too_many_attempts');
    sqlite.prepare('DELETE FROM parent_login_limits WHERE until_at < ?').run(now - 86400000);
  }
  const portalEnabled = school => !!school && Array.isArray(school.modules) && school.modules.includes('parent_portal');
  // Lazy index of phone -> school/student IDs. A row revision change rebuilds only that school's index.
  const rosterIndex = new Map();
  function enrollments(phone) {
    const rows = sqlite.prepare(`SELECT s.id,s.updated_at AS school_version,a.updated_at AS data_version
      FROM schools s JOIN app_data a ON a.school_id=s.id`).all();
    const alive = new Set(rows.map(r => r.id));
    for (const id of rosterIndex.keys()) if (!alive.has(id)) rosterIndex.delete(id);
    const out = [];
    for (const row of rows) {
      const version = String(row.school_version) + ':' + String(row.data_version);
      let index = rosterIndex.get(row.id);
      if (!index || index.version !== version) {
        const school = loadSchoolRow(row.id), byPhone = new Map();
        if (portalEnabled(school) && !schoolUnavailable(school)) {
          const data = applySoftDeletes(loadAppData(row.id), {});
          const classes = new Map((data.classes || []).map(c => [String(c.id), c]));
          for (const student of data.students || []) {
            if (!student || student.active === false || !classes.has(String(student.classId))) continue;
            for (const number of new Set(phones(student))) {
              if (!byPhone.has(number)) byPhone.set(number, []);
              byPhone.get(number).push({ schoolId: row.id, studentId: String(student.id), name: String(student.name || ''),
                schoolName: String(school.name || ''), className: String(classes.get(String(student.classId)).name || '') });
            }
          }
        }
        index = { version, byPhone }; rosterIndex.set(row.id, index);
      }
      // Licenses may expire at midnight without a database write.
      const school = loadSchoolRow(row.id);
      if (portalEnabled(school) && !schoolUnavailable(school)) out.push(...(index.byPhone.get(phone) || []));
    }
    return out;
  }
  function cookieOptions(req) {
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(req.hostname);
    return { httpOnly: true, secure: !local || req.secure, sameSite: 'strict', path: '/api/parents', maxAge: SESSION_MS };
  }
  function startSession(req, res, account) {
    const token = crypto.randomBytes(32).toString('hex');
    sqlite.prepare('DELETE FROM parent_sessions WHERE expires_at<=?').run(Date.now());
    sqlite.prepare('INSERT INTO parent_sessions VALUES(?,?,?,?)').run(hashToken(token), account.phone, account.version, Date.now() + SESSION_MS);
    res.cookie(COOKIE, token, cookieOptions(req));
  }
  function session(req, allowChange = false) {
    sameOrigin(req);
    const value = String(req.headers.cookie || '').split(';').map(p => p.trim()).find(p => p.startsWith(COOKIE + '='));
    const token = value ? value.slice(COOKIE.length + 1) : '';
    if (!/^[a-f0-9]{64}$/.test(token)) throw fail(401, 'login_required');
    const row = sqlite.prepare(`SELECT a.*,s.token_hash FROM parent_sessions s JOIN parent_accounts a ON a.phone=s.phone
      WHERE s.token_hash=? AND s.expires_at>? AND s.version=a.version`).get(hashToken(token), Date.now());
    if (!row) throw fail(401, 'login_required');
    if (!allowChange && row.must_change) throw fail(403, 'password_change_required');
    return row;
  }
  function childFor(phone, schoolId, studentId) {
    const child = enrollments(phone).find(c => c.schoolId === schoolId && c.studentId === studentId);
    if (!child) throw fail(404, 'student_not_found');
    return child;
  }
  const metadata = `id,school_id,student_id,parent_phone,dates,note,status,decision_note,reviewer,reviewed_at,created_at,file_name,file_mime`;
  function requestView(row) {
    return { id: row.id, schoolId: row.school_id, studentId: row.student_id, dates: JSON.parse(row.dates), note: row.note,
      status: row.status, decisionNote: row.decision_note, reviewedAt: row.reviewed_at, createdAt: row.created_at,
      fileName: row.file_name, fileType: row.file_mime };
  }
  function sendDocument(res, row) {
    res.set({ 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; sandbox", 'Content-Type': row.file_mime,
      'Content-Disposition': "attachment; filename=medical-document; filename*=UTF-8''" + encodeURIComponent(row.file_name) });
    res.send(row.file_data);
  }
  function childRequests(phone, schoolId, studentId) {
    return sqlite.prepare(`SELECT ${metadata} FROM parent_medical_requests WHERE parent_phone=? AND school_id=? AND student_id=? ORDER BY created_at DESC`)
      .all(phone, schoolId, studentId).map(requestView);
  }
  function childReport(child) {
    const data = applySoftDeletes(loadAppData(child.schoolId), {}), sid = child.studentId;
    const own = (data.attendance || []).filter(a => String(a.studentId) === sid);
    const rules = reportRules(data, sid);
    const absences = rules.absences.map(day => ({ date: day.date, excused: day.excused, count: day.count }));
    const discipline = own.filter(a => a.type !== 'absent').map(a => {
      const type = (data.disciplineTypes || []).find(t => t.id === a.type);
      const raw = Number.parseFloat(a.scoreDeduct);
      return { id: String(a.id || ''), date: normalizeDateToIso(a.date) || String(a.date || ''),
        type: a.type === 'late' ? 'late' : 'discipline', title: a.type === 'late' ? 'تأخیر' : String(a.typeName || (type && type.name) || 'مورد انضباطی'),
        note: a.type === 'late' ? '' : String(a.note || ''), excused: !!(a.excused || a.justified),
        scoreDeduct: a.excused || a.justified ? 0 : Number.isFinite(raw) ? raw : null };
    }).sort((a, b) => b.date.localeCompare(a.date));
    const student = (data.students || []).find(s => String(s.id) === sid);
    const exams = (data.exams || []).filter(ex => String(ex.classId) === String(student.classId) && ex.scores && ex.scores[sid] != null && ex.scores[sid] !== '')
      .map(ex => ({ id: String(ex.id), title: String(ex.title || ''), subject: String(ex.subject || ''),
        date: normalizeDateToIso(ex.date) || String(ex.date || ''), teacherName: String(ex.teacherName || ''),
        score: Number.isFinite(Number(ex.scores[sid])) ? Number(ex.scores[sid]) : null,
        maxScore: Number.parseFloat(ex.maxScore) || 20 })).sort((a, b) => b.date.localeCompare(a.date));
    const graded = exams.filter(e => e.score !== null && e.maxScore > 0);
    const average = graded.length ? Math.round(100 * graded.reduce((sum, e) => sum + e.score / e.maxScore * 20, 0) / graded.length) / 100 : null;
    return { child, disciplineScore: rules.score, average, absences, discipline, exams, updatedAt: data.updatedAtMs };
  }
  const router = express.Router();
  router.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  router.post('/login', wrap(async (req, res) => {
    sameOrigin(req);
    const phone = normalizePhone(req.body && req.body.phone), password = req.body && req.body.password;
    rateLimit('ip:' + req.socket.remoteAddress, 120, 1);
    if (!phone || typeof password !== 'string' || !password || password.length > 128) throw fail(401, 'invalid_credentials');
    rateLimit('phone:' + phone, 10, 15);
    let account = sqlite.prepare('SELECT * FROM parent_accounts WHERE phone=?').get(phone);
    const salt = account ? account.salt : 'nikan-parent-first-login-v1';
    const actual = await scrypt(password, salt, 64);
    const expected = account ? Buffer.from(account.hash, 'hex') : await scrypt('123456', salt, 64);
    if (!crypto.timingSafeEqual(actual, expected) || !enrollments(phone).length) throw fail(401, 'invalid_credentials');
    if (!account) {
      // A concurrent first login cannot overwrite an account or its password.
      const firstSalt = crypto.randomBytes(16).toString('hex');
      const firstHash = (await scrypt(password, firstSalt, 64)).toString('hex');
      const inserted = sqlite.prepare('INSERT INTO parent_accounts(phone,salt,hash,updated_at) VALUES(?,?,?,?) ON CONFLICT(phone) DO NOTHING')
        .run(phone, firstSalt, firstHash, Date.now());
      if (!inserted.changes) throw fail(401, 'invalid_credentials');
      account = sqlite.prepare('SELECT * FROM parent_accounts WHERE phone=?').get(phone);
      if (account.hash !== firstHash) throw fail(401, 'invalid_credentials');
    }
    // Re-read after asynchronous hashing so password reset/change invalidates in-flight login.
    const latest = sqlite.prepare('SELECT * FROM parent_accounts WHERE phone=?').get(phone);
    if (latest.hash !== account.hash || latest.version !== account.version) throw fail(401, 'invalid_credentials');
    startSession(req, res, account);
    json(res, { ok: true, mustChangePassword: !!account.must_change });
  }));
  router.post('/password', wrap(async (req, res) => {
    const account = session(req, true), password = req.body && req.body.password;
    rateLimit('password:' + account.phone, 10, 15);
    if (typeof password !== 'string' || password.length < 8 || password.length > 128 || /^([0-9])\1+$/.test(password) || password === '12345678') throw fail(400, 'invalid_password');
    const salt = crypto.randomBytes(16).toString('hex'), hash = (await scrypt(password, salt, 64)).toString('hex');
    const updated = sqlite.transaction(() => {
      const result = sqlite.prepare('UPDATE parent_accounts SET salt=?,hash=?,must_change=0,version=version+1,updated_at=? WHERE phone=? AND version=?')
        .run(salt, hash, Date.now(), account.phone, account.version);
      if (!result.changes) throw fail(401, 'login_required');
      sqlite.prepare('DELETE FROM parent_sessions WHERE phone=?').run(account.phone);
      return sqlite.prepare('SELECT * FROM parent_accounts WHERE phone=?').get(account.phone);
    })();
    startSession(req, res, updated); json(res, { ok: true });
  }));
  router.post('/logout', wrap((req, res) => {
    const account = session(req, true);
    sqlite.prepare('DELETE FROM parent_sessions WHERE token_hash=?').run(account.token_hash);
    res.clearCookie(COOKIE, { ...cookieOptions(req), maxAge: undefined }); json(res, { ok: true });
  }));
  router.get('/me', wrap((req, res) => {
    const account = session(req, true);
    json(res, { ok: true, mustChangePassword: !!account.must_change, children: account.must_change ? [] : enrollments(account.phone) });
  }));
  router.get('/students/:schoolId/:studentId', wrap((req, res) => {
    const account = session(req), child = childFor(account.phone, req.params.schoolId, req.params.studentId);
    json(res, { ok: true, report: childReport(child), requests: childRequests(account.phone, child.schoolId, child.studentId) });
  }));
  router.post('/requests', wrap((req, res) => {
    const account = session(req), body = req.body || {};
    rateLimit('upload:' + account.phone, 15, 60);
    const child = childFor(account.phone, String(body.schoolId || ''), String(body.studentId || ''));
    if (!Array.isArray(body.dates) || !body.dates.length || body.dates.length > 31) throw fail(400, 'invalid_dates');
    const dates = [...new Set(body.dates.map(validDate))].sort();
    if (dates.includes('') || typeof body.note !== 'string' || body.note.length > 2000) throw fail(400, 'invalid_request');
    const report = childReport(child);
    if (dates.some(date => !report.absences.some(a => a.date === date && !a.excused))) throw fail(409, 'absence_not_available');
    const pending = childRequests(account.phone, child.schoolId, child.studentId).filter(r => r.status === 'pending');
    if (pending.some(r => r.dates.some(day => dates.includes(day)))) throw fail(409, 'request_already_pending');
    const file = readFile(body.file), id = crypto.randomUUID();
    sqlite.prepare(`INSERT INTO parent_medical_requests(id,school_id,student_id,parent_phone,dates,note,created_at,file_name,file_mime,file_data)
      VALUES(?,?,?,?,?,?,?,?,?,?)`).run(id, child.schoolId, child.studentId, account.phone, JSON.stringify(dates), body.note.trim(), Date.now(), file.name, file.mime, file.bytes);
    json(res, { ok: true, id }, 201);
  }));
  router.get('/requests/:id/file', wrap((req, res) => {
    const account = session(req), row = sqlite.prepare('SELECT * FROM parent_medical_requests WHERE id=? AND parent_phone=?').get(req.params.id, account.phone);
    if (!row) throw fail(404, 'request_not_found');
    childFor(account.phone, row.school_id, row.student_id); sendDocument(res, row);
  }));
  router.use((req, res) => json(res, { ok: false, error: 'route_not_found' }, 404));
  app.use('/api/parents', router);

  function staff(req) {
    const schoolId = req.params.schoolId;
    const viewer = authenticateWrite(req, schoolId, req.body || {});
    if (!viewer.ok) throw fail(401, viewer.error || 'login_required');
    if (!['manager', 'deputy'].includes(viewer.role)) throw fail(403, 'forbidden');
    if (!portalEnabled(loadSchoolRow(schoolId))) throw fail(403, 'parent_portal_disabled');
    req.viewer = viewer;
    const full = applySoftDeletes(loadAppData(schoolId), {}), scoped = scopeAppDataForViewer(full, viewerQuery(req));
    return { full, students: new Map((scoped.students || []).map(s => [String(s.id), s])), viewer };
  }
  function staffRequest(req, access) {
    const row = sqlite.prepare('SELECT * FROM parent_medical_requests WHERE id=? AND school_id=?').get(req.params.id, req.params.schoolId);
    if (!row || !access.students.has(row.student_id)) throw fail(404, 'request_not_found');
    return row;
  }
  app.post('/api/schools/:schoolId/parents/reset-password', wrap(async (req, res) => {
    res.set('Cache-Control', 'no-store');
    sameOrigin(req);
    const access = staff(req), schoolId = req.params.schoolId;
    if (access.viewer.role !== 'manager') throw fail(403, 'forbidden');
    const phone = normalizePhone(req.body && req.body.phone);
    if (!phone) throw fail(400, 'invalid_phone');
    const linked = () => enrollments(phone).some(child => child.schoolId === schoolId);
    if (!linked()) throw fail(404, 'parent_not_found');
    const account = sqlite.prepare('SELECT version FROM parent_accounts WHERE phone=?').get(phone);
    if (!account) throw fail(404, 'parent_account_not_found');
    rateLimit('reset-manager:' + schoolId + ':' + access.viewer.user, 20, 60);
    rateLimit('reset-parent:' + phone, 3, 15);
    const temporary = '123456', salt = crypto.randomBytes(16).toString('hex');
    const hash = (await scrypt(temporary, salt, 64)).toString('hex');
    sqlite.transaction(() => {
      // Recheck the manager, school feature and roster after asynchronous password hashing.
      delete req.viewer;
      if (staff(req).viewer.role !== 'manager') throw fail(403, 'forbidden');
      if (!linked()) throw fail(404, 'parent_not_found');
      const updated = sqlite.prepare('UPDATE parent_accounts SET salt=?,hash=?,must_change=1,version=version+1,updated_at=? WHERE phone=? AND version=?')
        .run(salt, hash, Date.now(), phone, account.version);
      if (!updated.changes) throw fail(409, 'account_changed');
      sqlite.prepare('DELETE FROM parent_sessions WHERE phone=?').run(phone);
      sqlite.prepare('DELETE FROM parent_login_limits WHERE key IN (?,?)').run('phone:' + phone, 'password:' + phone);
    })();
    // Manager-requested recovery to the initial password; only its salted hash is stored.
    json(res, { ok: true, temporaryPassword: temporary, mustChangePassword: true });
  }));
  app.get('/api/schools/:schoolId/parent-requests', wrap((req, res) => {
    const access = staff(req);
    const requests = sqlite.prepare(`SELECT ${metadata} FROM parent_medical_requests WHERE school_id=? ORDER BY created_at DESC`)
      .all(req.params.schoolId).filter(row => access.students.has(row.student_id)).map(row => {
        const s = access.students.get(row.student_id), c = (access.full.classes || []).find(c => String(c.id) === String(s.classId));
        return { ...requestView(row), studentName: String(s.name || ''), className: c ? String(c.name || '') : '',
          reviewer: row.reviewer, parentPhone: row.parent_phone };
      });
    json(res, { ok: true, requests });
  }));
  app.get('/api/schools/:schoolId/parent-requests/:id/file', wrap((req, res) => {
    const access = staff(req); sendDocument(res, staffRequest(req, access));
  }));
  app.post('/api/schools/:schoolId/parent-requests/:id/review', wrap((req, res) => {
    const body = req.body || {};
    if (!['approved', 'rejected'].includes(body.status) || typeof body.note !== 'string' || body.note.length > 2000 || (body.status === 'rejected' && !body.note.trim())) throw fail(400, 'invalid_decision');
    const result = sqlite.transaction(() => {
      const access = staff(req), row = staffRequest(req, access);
      if (row.status !== 'pending') throw fail(409, 'request_already_reviewed');
      const days = new Set(JSON.parse(row.dates));
      if (body.status === 'approved') {
        const relevant = (access.full.attendance || []).filter(a => String(a.studentId) === row.student_id && a.type === 'absent' && days.has(validDate(a.date)));
        if ([...days].some(day => !relevant.some(a => validDate(a.date) === day))) throw fail(409, 'absence_not_available');
        const now = Date.now();
        // Preserve existing school's same-day excuse rule (absence + late); never touch another day/student.
        access.full.attendance = (access.full.attendance || []).map(a => {
          if (String(a.studentId) !== row.student_id || !['absent', 'late'].includes(a.type) || !days.has(validDate(a.date))) return a;
          return { ...a, excused: true, justified: true, scoreDeduct: 0, scoreLocked: true, updatedAtMs: now,
            note: String(a.note || '').includes('موجه') ? a.note : (a.note ? a.note + ' · ' : '') + 'موجه' };
        });
        // Canonical persistence also updates the school's polling revision and preserves the private notebook.
        saveAppData(req.params.schoolId, access.full);
      }
      sqlite.prepare('UPDATE parent_medical_requests SET status=?,decision_note=?,reviewer=?,reviewed_at=? WHERE id=?')
        .run(body.status, body.note.trim(), access.viewer.user || access.viewer.staffId, Date.now(), row.id);
      return requestView(sqlite.prepare(`SELECT ${metadata} FROM parent_medical_requests WHERE id=?`).get(row.id));
    })();
    json(res, { ok: true, request: result });
  }));
}
module.exports = { installParentPortal, normalizePhone, validDate };
