/* Medical request review: manager/deputy credentials stay in the existing API client. */
(function(){
'use strict';
let generation=0;
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusLabel={pending:'در انتظار بررسی',approved:'تأیید شده',rejected:'رد شده'};
function root(){return document.getElementById('parent-request-list');}
function clearRecovery(){
 const result=document.getElementById('parent-reset-result');if(result){result.replaceChildren();result.hidden=true;}
 const form=document.getElementById('parent-password-reset-form');if(form)form.reset();
}
function syncRecovery(){
 const card=document.getElementById('parent-password-card');
 if(card)card.hidden=!(parentPortalEnabled()&&userSession&&userSession.role==='manager');
 clearRecovery();
}
const previousLogout=window.doLogout;
window.doLogout=function(){generation++;clearRecovery();const box=root();if(box)box.replaceChildren();return previousLogout.apply(this,arguments);};
function url(id,suffix){return '/api/schools/'+encodeURIComponent(session.schoolId)+'/parent-requests'+(id?'/'+encodeURIComponent(id):'')+(suffix||'');}
function currentKey(){return JSON.stringify([session&&session.schoolId,userSession&&userSession.username,userSession&&userSession.role,parentPortalEnabled()]);}
window.syncParentPortalAccess=function(){
 if(parentPortalEnabled())return;
 generation++;syncRecovery();const box=root();if(box)box.replaceChildren();
 const page=document.getElementById('page-parent-requests');
 if(page&&page.classList.contains('active'))showAppPage('home');
};
window.openParentRequests=async function(){
 if(!canManage())return toast('فقط مدیر و معاون');
 if(!parentPortalEnabled()){window.syncParentPortalAccess();return toast('پنل والدین از پنل مادر برای این مدرسه فعال نشده است');}
 syncRecovery();showAppPage('parent-requests');const g=++generation,key=currentKey();root().textContent='در حال دریافت درخواست‌ها...';
 try{
  const result=await apiFetch(url(),{retries:1});if(g!==generation||key!==currentKey())return;
  const filter=document.getElementById('parent-request-status').value;
  const rows=result.requests.filter(q=>filter==='all'||q.status===filter);root().replaceChildren();
  if(!rows.length){root().textContent='درخواستی در این بخش نیست.';return;}
  rows.forEach(q=>{
   const card=document.createElement('div');card.className='card';
   const reviewLabel=q.reviewedAt?' · بررسی: '+new Date(q.reviewedAt).toLocaleString('fa-IR'):'';
   card.innerHTML='<div class="card-title">'+esc(q.studentName)+' · '+esc(q.className)+'</div><p>'+esc(statusLabel[q.status])+'</p><p class="hint">روزها: '+q.dates.map(d=>esc(formatDateFa(d))).join('، ')+'</p><p class="hint">شماره ولی: '+esc(q.parentPhone)+' · ارسال: '+esc(new Date(q.createdAt).toLocaleString('fa-IR'))+esc(reviewLabel)+'</p><p style="white-space:pre-wrap">'+esc(q.note)+'</p>'+(q.decisionNote?'<p style="white-space:pre-wrap">پاسخ: '+esc(q.decisionNote)+'</p>':'');
   const download=document.createElement('button');download.type='button';download.className='btn btn-outline';download.textContent='دریافت گواهی';
   download.onclick=()=>downloadFile(q,download,key);card.append(download);
   if(q.status==='pending'){
    const label=document.createElement('label');label.textContent='توضیح پاسخ (برای رد الزامی)';label.style.display='block';label.style.marginTop='12px';
    const note=document.createElement('textarea');note.className='form-control';note.maxLength=2000;note.rows=2;label.append(note);card.append(label);
    const hint=document.createElement('p');hint.className='hint';hint.textContent='تأیید طبق قواعد فعلی، غیبت و تأخیر همان روزهای انتخاب‌شده را موجه و کسر آن‌ها را صفر می‌کند.';card.append(hint);
    const actions=[];
    for(const [status,text,cls] of [['approved','تأیید و موجه‌کردن','btn-success'],['rejected','رد درخواست','btn-danger']]){
     const button=document.createElement('button');button.type='button';button.textContent=text;button.className='btn '+cls;button.style.margin='6px';actions.push(button);
     button.onclick=async()=>{
      if(key!==currentKey())return;
      if(status==='rejected'&&!note.value.trim())return toast('دلیل رد را بنویسید');
      if(!confirm(status==='approved'?'گواهی بررسی شد و این روزها موجه شوند؟':'درخواست با این توضیح رد شود؟'))return;
      actions.forEach(b=>b.disabled=true);
      try{await apiFetch(url(q.id,'/review'),{method:'POST',body:{status,note:note.value},retries:1});if(key!==currentKey())return;toast('نتیجه روی سرور ذخیره شد');try{await cloudPullAppData(true)}catch{}await window.openParentRequests();}
      catch(e){if(key===currentKey())toast('ثبت نتیجه انجام نشد؛ دوباره دریافت کنید');actions.forEach(b=>b.disabled=false);}
     };card.append(button);
    }
   }
   root().append(card);
  });
 }catch(e){if(g===generation&&key===currentKey())root().textContent='دریافت درخواست‌ها انجام نشد. اتصال و دسترسی را بررسی و دوباره تلاش کنید.';}
};
const resetForm=document.getElementById('parent-password-reset-form');
if(resetForm)resetForm.onsubmit=async event=>{
 event.preventDefault();
 const button=resetForm.querySelector('button[type=submit]');if(button.disabled)return;
 if(!parentPortalEnabled()||!userSession||userSession.role!=='manager')return toast('فقط مدیر مدرسه با قابلیت والدین فعال');
 if(!confirm('هویت ولی را بررسی کرده‌اید؟ رمز این شماره به 123456 برگردد و تمام نشست‌های قبلی آن بسته شود؟'))return;
 const key=currentKey(),g=generation,phone=document.getElementById('parent-reset-phone').value;
 const result=document.getElementById('parent-reset-result');result.replaceChildren();result.hidden=true;button.disabled=true;
 try{
  const response=await apiFetch('/api/schools/'+encodeURIComponent(session.schoolId)+'/parents/reset-password',{method:'POST',body:{phone},retries:1});
  if(key!==currentKey()||g!==generation)return;
  const label=document.createElement('p');label.textContent='رمز والد به حالت اولیه برگشت:';
  const password=document.createElement('code');password.dir='ltr';password.style.cssText='display:inline-block;font-size:1.3rem;user-select:all;padding:10px;background:#edf3f7;color:#102743;border-radius:8px';password.textContent=response.temporaryPassword;
  const hint=document.createElement('p');hint.className='hint';hint.textContent='ولی با شماره موبایل و رمز 123456 وارد شود و سپس رمز شخصی تازه تعیین کند.';
  const close=document.createElement('button');close.type='button';close.className='btn btn-outline';close.textContent='بستن';close.onclick=clearRecovery;
  result.append(label,password,hint,close);result.hidden=false;
 }catch(error){
  if(key!==currentKey()||g!==generation)return;
  const messages={parent_account_not_found:'ولی هنوز ورود اولیه انجام نداده است؛ با رمز اولیه وارد شود.',parent_not_found:'این شماره به دانش‌آموز فعال مدرسه شما متصل نیست.',invalid_phone:'شماره موبایل معتبر وارد کنید.',too_many_attempts:'تعداد بازنشانی‌ها زیاد است؛ کمی بعد تلاش کنید.',account_changed:'حساب هم‌زمان تغییر کرده است؛ دوباره بررسی کنید.',parent_portal_disabled:'پنل والدین برای مدرسه فعال نیست.'};
  result.textContent=messages[error.message]||'بازنشانی انجام نشد؛ اتصال و دسترسی مدیر را بررسی کنید.';result.hidden=false;
 }finally{button.disabled=false;}
};
async function downloadFile(q,button,key){
 if(key!==currentKey())return;button.disabled=true;
 try{
  const auth=getWriteAuth();const response=await fetch(url(q.id,'/file'),{headers:{'X-Auth-User':encodeURIComponent(auth.user),'X-Auth-Pass':encodeURIComponent(auth.pass),'X-Auth-Encoding':'uri-component','X-Auth-Role':auth.role},cache:'no-store'});
  if(!response.ok)throw new Error();const blob=await response.blob();if(key!==currentKey())return;
  const objectUrl=URL.createObjectURL(blob),a=document.createElement('a');a.href=objectUrl;a.download=q.fileName;a.click();setTimeout(()=>URL.revokeObjectURL(objectUrl),30000);
 }catch{toast('دریافت گواهی ناموفق بود');}finally{button.disabled=false;}
}
})();
